import struct
import json
import os

with open('lovelink-frontend/public/models/male_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, _ = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))
    f.seek(12 + 8 + chunk_len)
    bin_len, _ = struct.unpack('<II', f.read(8))
    bin_data = f.read(bin_len)

images = g.get('images', [])
buffer_views = g.get('bufferViews', [])

os.makedirs('scratch/extracted_male', exist_ok=True)
for i, img in enumerate(images):
    name = img.get('name', f'image_{i}')
    bv_idx = img.get('bufferView')
    mime = img.get('mimeType', 'image/png')
    ext = 'jpg' if 'jpeg' in mime else 'png'
    bv = buffer_views[bv_idx]
    offset = bv.get('byteOffset', 0)
    byte_len = bv.get('byteLength')
    img_bytes = bin_data[offset:offset+byte_len]
    out_path = f'scratch/extracted_male/{i}_{name}.{ext}'
    with open(out_path, 'wb') as out_f:
        out_f.write(img_bytes)
    print(f"Extracted male image {i}: {name} ({mime}, {byte_len} bytes) -> {out_path}")
