const fs = require('fs');

// Let's render female_avatar.glb in node with Three.js and headless-gl or inspect the material!
// Let's check how the texture colors look on the hand vertices!

const { JSDOM } = require('jsdom');
// Or we can calculate it directly using Three.js math!
const buffer = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const chunkLength = buffer.readUInt32LE(12);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);
const binChunk = buffer.subarray(28 + chunkLength);

const leftHandData = JSON.parse(fs.readFileSync('scratch/left_hand_uvs.json', 'utf8'));

console.log('Total left hand vertices:', leftHandData.length);

// Let's check the UV range for left hand:
let minU = 1e9, maxU = -1e9, minV = 1e9, maxV = -1e9;
for (const item of leftHandData) {
  const [u, v] = item.uv0;
  if (u < minU) minU = u;
  if (u > maxU) maxU = u;
  if (v < minV) minV = v;
  if (v > maxV) maxV = v;
}
console.log('Left hand UV0:', { minU, maxU, minV, maxV });
