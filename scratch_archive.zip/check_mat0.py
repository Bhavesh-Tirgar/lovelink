import struct
import json

with open('lovelink-frontend/public/models/female_avatar.glb', 'rb') as f:
    magic, version, length = struct.unpack('<4sII', f.read(12))
    chunk_len, chunk_type = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))

print("Material 0:", json.dumps(g['materials'][0], indent=2))
print("Material 4:", json.dumps(g['materials'][4], indent=2))
