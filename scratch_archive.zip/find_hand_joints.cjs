const fs = require('fs');

const buffer = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const chunkLength = buffer.readUInt32LE(12);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);
const binChunk = buffer.subarray(28 + chunkLength);

// Let's find joints in skin 0
const skin = gltf.skins[0];
console.log('Skin joints count:', skin.joints.length);
skin.joints.forEach((nodeIdx, jIdx) => {
  const node = gltf.nodes[nodeIdx];
  if (node.name.toLowerCase().includes('hand') || node.name.toLowerCase().includes('wrist') || node.name.toLowerCase().includes('arm')) {
    console.log(`Joint ${jIdx}: Node ${nodeIdx} -> ${node.name}`);
  }
});
