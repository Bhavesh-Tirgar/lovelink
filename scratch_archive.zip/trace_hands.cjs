const fs = require('fs');

function traceNode(gltf, targetName) {
  const targetIdx = gltf.nodes.findIndex(n => n.name === targetName);
  let path = [targetName];
  let curr = targetIdx;
  let totalT = [0, 0, 0];
  while (curr !== -1) {
    const node = gltf.nodes[curr];
    if (node.translation) {
      totalT[0] += node.translation[0];
      totalT[1] += node.translation[1];
      totalT[2] += node.translation[2];
    }
    // find parent
    const parentIdx = gltf.nodes.findIndex(n => n.children && n.children.includes(curr));
    if (parentIdx !== -1) {
      path.push(gltf.nodes[parentIdx].name || `node_${parentIdx}`);
      curr = parentIdx;
    } else {
      break;
    }
  }
  return { path: path.reverse().join(' -> '), totalT };
}

const bufferF = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const chunkLengthF = bufferF.readUInt32LE(12);
const gltfF = JSON.parse(bufferF.subarray(20, 20 + chunkLengthF).toString('utf8'));

const bufferM = fs.readFileSync('lovelink-frontend/public/models/male_avatar.glb');
const chunkLengthM = bufferM.readUInt32LE(12);
const gltfM = JSON.parse(bufferM.subarray(20, 20 + chunkLengthM).toString('utf8'));

console.log('Female LeftHand:');
console.log(traceNode(gltfF, 'LeftHand'));
console.log('Female RightHand:');
console.log(traceNode(gltfF, 'RightHand'));

console.log('Male LeftHand:');
console.log(traceNode(gltfM, 'LeftHand'));
console.log('Male RightHand:');
console.log(traceNode(gltfM, 'RightHand'));
