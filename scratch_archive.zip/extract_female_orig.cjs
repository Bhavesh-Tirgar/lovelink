const fs = require('fs');

const buffer = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const chunkLength = buffer.readUInt32LE(12);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);

const binChunk = buffer.subarray(28 + chunkLength);

// Image 0 bufferView: 0
const bv = gltf.bufferViews[0];
console.log('bv 0:', bv);
const imgBuf = binChunk.subarray(bv.byteOffset, bv.byteOffset + bv.byteLength);
fs.writeFileSync('scratch/original_female_body_base_color.png', imgBuf);
console.log('Extracted scratch/original_female_body_base_color.png, bytes:', imgBuf.length);

const cleanedStats = fs.statSync('lovelink-frontend/public/models/female_skin_cleaned.png');
console.log('Cleaned skin texture bytes:', cleanedStats.size);
