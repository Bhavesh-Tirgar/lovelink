import struct
import json

with open('lovelink-frontend/public/models/female_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, _ = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))

p_pants = g['meshes'][8]['primitives'][0]
pos_acc = g['accessors'][p_pants['attributes']['POSITION']]
print("Female PANTS position accessor:", pos_acc)
