import struct
import json

with open('lovelink-frontend/public/models/male_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, _ = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))

p_bot = g['meshes'][5]['primitives'][0]
pos_acc_idx = p_bot['attributes']['POSITION']
pos_acc = g['accessors'][pos_acc_idx]
print("POSITION accessor:", pos_acc)
print("Extensions used:", g.get('extensionsUsed'))
print("Extensions required:", g.get('extensionsRequired'))
