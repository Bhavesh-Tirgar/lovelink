import re

path = 'lovelink-frontend/src/components/Real3DAvatarStage.jsx'
with open(path, 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Texture wrapping for cleanSkinTex
old_tex = """    const cleanSkinTex = texLoader.load('/models/female_skin_cleaned.png');
    cleanSkinTex.flipY = false;
    cleanSkinTex.colorSpace = THREE.SRGBColorSpace;"""

new_tex = """    const cleanSkinTex = texLoader.load('/models/female_skin_cleaned.png');
    cleanSkinTex.flipY = false;
    cleanSkinTex.colorSpace = THREE.SRGBColorSpace;
    cleanSkinTex.wrapS = THREE.RepeatWrapping;
    cleanSkinTex.wrapT = THREE.RepeatWrapping;"""

assert old_tex in code, "old_tex not found"
code = code.replace(old_tex, new_tex, 1)

# 2. Female Model Scale & Rest Pose
old_female_scale = """        model.position.set(-0.38, 0.08, 0);
        model.scale.set(1.135, 1.135, 1.135);"""

new_female_scale = """        model.position.set(-0.38, 0.08, 0);
        model.scale.set(1.18, 1.18, 1.18);"""

assert old_female_scale in code, "old_female_scale not found"
code = code.replace(old_female_scale, new_female_scale, 1)

# 3. Female Hands Rest Wrists and Fingers
old_female_hands = """        // Wrists: natural relaxed downward drop
        if (leftBonesRef.current.leftHand) leftBonesRef.current.leftHand.rotation.set(0.05, -0.10, -0.05);
        if (leftBonesRef.current.rightHand) leftBonesRef.current.rightHand.rotation.set(0.05, 0.10, 0.05);

        // Natural graceful human resting finger curve (inverted for Left vs Right to curl toward palm)
        const curlFingers = (side) => {
          const prefix = side === 'left' ? 'leftHand' : 'rightHand';
          const isLeft = side === 'left';
          ['Index', 'Middle', 'Ring', 'Pinky'].forEach((f, idx) => {
            const curlAmt = 0.28 + idx * 0.035;
            for (let j = 1; j <= 3; j++) {
              const b = leftBonesRef.current[`${prefix}${f}${j}`];
              if (b) {
                const factor = j === 1 ? 0.9 : j === 2 ? 1.05 : 0.8;
                b.rotation.x = isLeft ? -curlAmt * factor : curlAmt * factor;
              }
            }
          });
          const t1 = leftBonesRef.current[`${prefix}Thumb1`];
          const t2 = leftBonesRef.current[`${prefix}Thumb2`];
          if (t1) {
            t1.rotation.set(isLeft ? -0.16 : 0.16, isLeft ? 0.12 : -0.12, isLeft ? -0.08 : 0.08);
          }
          if (t2) {
            t2.rotation.x = isLeft ? -0.18 : 0.18;
          }
        };"""

new_female_hands = """        // Wrists: natural relaxed downward drop (no outward splay)
        if (leftBonesRef.current.leftHand) leftBonesRef.current.leftHand.rotation.set(0.04, -0.02, 0.0);
        if (leftBonesRef.current.rightHand) leftBonesRef.current.rightHand.rotation.set(0.04, 0.02, 0.0);

        // Natural graceful human resting finger curve (soft human relaxation, zero claw hyperextension)
        const curlFingers = (side) => {
          const prefix = side === 'left' ? 'leftHand' : 'rightHand';
          const isLeft = side === 'left';
          ['Index', 'Middle', 'Ring', 'Pinky'].forEach((f, idx) => {
            const curlAmt = 0.10 + idx * 0.015;
            for (let j = 1; j <= 3; j++) {
              const b = leftBonesRef.current[`${prefix}${f}${j}`];
              if (b) {
                const factor = j === 1 ? 0.6 : j === 2 ? 0.7 : 0.5;
                b.rotation.x = isLeft ? -curlAmt * factor : curlAmt * factor;
              }
            }
          });
          const t1 = leftBonesRef.current[`${prefix}Thumb1`];
          const t2 = leftBonesRef.current[`${prefix}Thumb2`];
          if (t1) {
            t1.rotation.set(isLeft ? -0.06 : 0.06, isLeft ? 0.05 : -0.05, isLeft ? -0.03 : 0.03);
          }
          if (t2) {
            t2.rotation.x = isLeft ? -0.08 : 0.08;
          }
        };"""

assert old_female_hands in code, "old_female_hands not found"
code = code.replace(old_female_hands, new_female_hands, 1)

# 4. Male Model Scale & Skin
old_male_scale = """        model.position.set(0.38, 0.08, 0);
        model.scale.set(0.98, 0.98, 0.98);"""

new_male_scale = """        model.position.set(0.38, 0.08, 0);
        model.scale.set(0.89, 0.89, 0.89);"""

assert old_male_scale in code, "old_male_scale not found"
code = code.replace(old_male_scale, new_male_scale, 1)

old_male_skin = """            if (name.includes('head') || name.includes('body')) {
              const sm = Array.isArray(child.material) ? child.material[0] : child.material;
              sm.color.setHex(0xfdebe1);
              sm.roughness = 0.68;
              sm.metalness = 0.0;
            }"""

new_male_skin = """            if (name.includes('head') || name.includes('body')) {
              const sm = Array.isArray(child.material) ? child.material[0] : child.material;
              sm.color.setHex(0xffffff); // Display authentic photographic skin tone
              sm.roughness = 0.68;
              sm.metalness = 0.0;
            }"""

assert old_male_skin in code, "old_male_skin not found"
code = code.replace(old_male_skin, new_male_skin, 1)

# 5. Clink, Kiss, Hug Emotes and Idle in animate loop
old_emotes = """        // EMOTE OVERRIDES - REALISTIC EXPRESSIVE ROMANTIC COUPLE INTERACTIONS
        if (currentEmote === 'clink' && emoteProgress < 1.0) {
          // Show 3D Ceramic Coffee Cups in hands
          if (girlCupRef.current) girlCupRef.current.visible = true;
          if (boyCupRef.current) boyCupRef.current.visible = true;

          // Smooth cubic ease-in-out curve
          const env = Math.sin(emoteProgress * Math.PI) * (1 - 0.12 * Math.sin(emoteProgress * Math.PI * 2));

          // Both avatars step closer together to toast coffee
          leftModel.position.x = THREE.MathUtils.lerp(-0.44, -0.28, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.44, 0.28, env);
          leftModel.rotation.y = THREE.MathUtils.lerp(0, 0.26, env);
          rightModel.rotation.y = THREE.MathUtils.lerp(0, -0.26, env);

          // Torso leans in warmly
          if (leftBones.spine) leftBones.spine.rotation.z = -0.06 * env;
          if (rightBones.spine) rightBones.spine.rotation.z = 0.06 * env;

          // Heads turn to each other with smiling eye contact
          if (leftBones.head) {
            leftBones.head.rotation.y = THREE.MathUtils.lerp(0, 0.38, env);
            leftBones.head.rotation.x = THREE.MathUtils.lerp(0, 0.08, env);
          }
          if (rightBones.head) {
            rightBones.head.rotation.y = THREE.MathUtils.lerp(0, -0.38, env);
            rightBones.head.rotation.x = THREE.MathUtils.lerp(0, 0.08, env);
          }

          // Girl raises INNER arm (LeftArm) forward holding coffee mug
          if (leftBones.leftArm) {
            leftBones.leftArm.rotation.x = THREE.MathUtils.lerp(0.958, 0.65, env);
            leftBones.leftArm.rotation.y = THREE.MathUtils.lerp(-1.592, -0.85, env);
            leftBones.leftArm.rotation.z = THREE.MathUtils.lerp(2.408, 0.35, env);
          }
          if (leftBones.leftForeArm) {
            leftBones.leftForeArm.rotation.x = THREE.MathUtils.lerp(0, -0.75, env);
            leftBones.leftForeArm.rotation.y = THREE.MathUtils.lerp(-0.45, -0.30, env);
            leftBones.leftForeArm.rotation.z = THREE.MathUtils.lerp(0, 0.45, env);
          }
          if (leftBones.leftHand) {
            leftBones.leftHand.rotation.set(0.15 * env, -0.20 * env, 0.10 * env);
          }

          // Girl outer arm rests naturally at side
          if (leftBones.rightArm) leftBones.rightArm.rotation.set(-2.192, -1.592, -0.742);
          if (leftBones.rightForeArm) leftBones.rightForeArm.rotation.set(0, 0.45, 0);

          // Boy raises INNER arm (RightArm) forward to meet her mug
          if (rightBones.rightArm) {
            rightBones.rightArm.rotation.x = THREE.MathUtils.lerp(1.350, 0.65, env);
            rightBones.rightArm.rotation.y = THREE.MathUtils.lerp(0.600, 0.85, env);
            rightBones.rightArm.rotation.z = THREE.MathUtils.lerp(0.100, -0.35, env);
          }
          if (rightBones.rightForeArm) {
            rightBones.rightForeArm.rotation.x = THREE.MathUtils.lerp(0, -0.75, env);
            rightBones.rightForeArm.rotation.y = THREE.MathUtils.lerp(0, 0.30, env);
            rightBones.rightForeArm.rotation.z = THREE.MathUtils.lerp(0, -0.45, env);
          }
          if (rightBones.rightHand) {
            rightBones.rightHand.rotation.set(0.15 * env, 0.20 * env, -0.10 * env);
          }

          // Boy outer arm rests naturally at side
          if (rightBones.leftArm) rightBones.leftArm.rotation.set(1.350, -0.600, -0.100);
          if (rightBones.leftForeArm) rightBones.leftForeArm.rotation.set(0, 0, 0);

        } else if (currentEmote === 'kiss' && emoteProgress < 1.0) {
          // Hide coffee cups
          if (girlCupRef.current) girlCupRef.current.visible = false;
          if (boyCupRef.current) boyCupRef.current.visible = false;

          const env = Math.sin(emoteProgress * Math.PI) * (1 - 0.08 * Math.sin(emoteProgress * Math.PI * 2));

          // Romantic close step-in for lip-to-lip kiss proximity
          leftModel.position.x = THREE.MathUtils.lerp(-0.44, -0.165, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.44, 0.165, env);
          leftModel.rotation.y = THREE.MathUtils.lerp(0, 0.45, env);
          rightModel.rotation.y = THREE.MathUtils.lerp(0, -0.45, env);

          // Romantic spine tilt toward partner
          if (leftBones.spine) leftBones.spine.rotation.z = -0.10 * env;
          if (rightBones.spine) rightBones.spine.rotation.z = 0.10 * env;

          // Complementary romantic head angles for close lip alignment
          if (leftBones.head) {
            leftBones.head.rotation.set(0.06 * env, 0.52 * env, 0.16 * env);
          }
          if (rightBones.head) {
            rightBones.head.rotation.set(0.06 * env, -0.52 * env, -0.16 * env);
          }

          // Girl arms wrap tenderly near partner
          if (leftBones.leftArm) {
            leftBones.leftArm.rotation.set(0.55 * env, -0.65 * env, 0.45 * env);
          }
          if (leftBones.leftForeArm) {
            leftBones.leftForeArm.rotation.set(-1.15 * env, -0.25 * env, 0.65 * env);
          }

          // Boy arms wrap tenderly near her waist
          if (rightBones.rightArm) {
            rightBones.rightArm.rotation.set(0.55 * env, 0.65 * env, -0.45 * env);
          }
          if (rightBones.rightForeArm) {
            rightBones.rightForeArm.rotation.set(-0.95 * env, 0.25 * env, -0.45 * env);
          }

          // Outer arms resting naturally close
          if (leftBones.rightArm) leftBones.rightArm.rotation.set(-2.192, -1.592, -0.742);
          if (leftBones.rightForeArm) leftBones.rightForeArm.rotation.set(0, 0.45, 0);
          if (rightBones.leftArm) rightBones.leftArm.rotation.set(1.350, -0.600, -0.100);
          if (rightBones.leftForeArm) rightBones.leftForeArm.rotation.set(0, 0, 0);

        } else if (currentEmote === 'hug' && emoteProgress < 1.0) {
          // Hide coffee cups
          if (girlCupRef.current) girlCupRef.current.visible = false;
          if (boyCupRef.current) boyCupRef.current.visible = false;

          const env = Math.sin(emoteProgress * Math.PI) * (1 - 0.10 * Math.sin(emoteProgress * Math.PI * 2));
          const squeeze = Math.sin((emoteProgress - 0.5) * 8) * 0.012;

          // Both avatars step into warm intimate couple embrace
          leftModel.position.x = THREE.MathUtils.lerp(-0.44, -0.145 + squeeze, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.44, 0.145 - squeeze, env);
          leftModel.rotation.y = THREE.MathUtils.lerp(0, 0.38, env);
          rightModel.rotation.y = THREE.MathUtils.lerp(0, -0.38, env);

          // Head resting lovingly on partner's shoulder
          if (leftBones.head) {
            leftBones.head.rotation.set(0.08 * env, 0.46 * env, 0.22 * env);
          }
          if (rightBones.head) {
            rightBones.head.rotation.set(0.08 * env, -0.46 * env, -0.18 * env);
          }

          // Spines lean into each other
          if (leftBones.spine) leftBones.spine.rotation.z = -0.06 * env;
          if (rightBones.spine) rightBones.spine.rotation.z = 0.06 * env;

          // Girl wraps both arms lovingly around boy's neck & waist
          if (leftBones.leftArm) {
            leftBones.leftArm.rotation.set(0.45 * env, -0.65 * env, 0.30 * env);
          }
          if (leftBones.leftForeArm) {
            leftBones.leftForeArm.rotation.set(-1.35 * env, -0.25 * env, 0.75 * env);
          }
          if (leftBones.rightArm) {
            leftBones.rightArm.rotation.set(-1.45 * env, -0.85 * env, -0.55 * env);
          }
          if (leftBones.rightForeArm) {
            leftBones.rightForeArm.rotation.set(-0.85 * env, 0.35 * env, -0.45 * env);
          }

          // Boy wraps both arms securely around girl's upper back & waist
          if (rightBones.rightArm) {
            rightBones.rightArm.rotation.set(0.45 * env, 0.65 * env, -0.30 * env);
          }
          if (rightBones.rightForeArm) {
            rightBones.rightForeArm.rotation.set(-1.35 * env, 0.25 * env, -0.75 * env);
          }
          if (rightBones.leftArm) {
            rightBones.leftArm.rotation.set(1.10 * env, -0.45 * env, -0.35 * env);
          }
          if (rightBones.leftForeArm) {
            rightBones.leftForeArm.rotation.set(0.85 * env, 0.25 * env, -0.65 * env);
          }"""

new_emotes = """        // EMOTE OVERRIDES - REALISTIC EXPRESSIVE ROMANTIC COUPLE INTERACTIONS
        if (currentEmote === 'clink' && emoteProgress < 1.0) {
          // Show 3D Ceramic Coffee Cups in hands
          if (girlCupRef.current) girlCupRef.current.visible = true;
          if (boyCupRef.current) boyCupRef.current.visible = true;

          // Smooth cubic ease-in-out curve
          const env = Math.sin(emoteProgress * Math.PI) * (1 - 0.12 * Math.sin(emoteProgress * Math.PI * 2));

          // Subtle clink tap recoil at mid-emote when mugs meet
          const tapRecoil = emoteProgress > 0.44 && emoteProgress < 0.62
            ? Math.sin((emoteProgress - 0.44) * Math.PI / 0.18) * 0.02
            : 0;

          // Both avatars step closer together to toast coffee
          leftModel.position.x = THREE.MathUtils.lerp(-0.38, -0.22, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.38, 0.22, env);
          leftModel.rotation.y = THREE.MathUtils.lerp(0, 0.28, env);
          rightModel.rotation.y = THREE.MathUtils.lerp(0, -0.28, env);

          // Torso leans in warmly
          if (leftBones.spine) leftBones.spine.rotation.z = -0.05 * env;
          if (rightBones.spine) rightBones.spine.rotation.z = 0.05 * env;

          // Heads turn to each other with smiling eye contact
          if (leftBones.head) {
            leftBones.head.rotation.y = THREE.MathUtils.lerp(0, 0.38, env);
            leftBones.head.rotation.x = THREE.MathUtils.lerp(0, 0.08, env);
          }
          if (rightBones.head) {
            rightBones.head.rotation.y = THREE.MathUtils.lerp(0, -0.38, env);
            rightBones.head.rotation.x = THREE.MathUtils.lerp(0, 0.08, env);
          }

          // Girl raises LeftArm forward holding coffee mug to center meeting point
          if (leftBones.leftArm) {
            leftBones.leftArm.rotation.x = THREE.MathUtils.lerp(0.958, 1.10, env);
            leftBones.leftArm.rotation.y = THREE.MathUtils.lerp(-1.592, -1.45, env);
            leftBones.leftArm.rotation.z = THREE.MathUtils.lerp(2.408, 1.55, env);
          }
          if (leftBones.leftForeArm) {
            leftBones.leftForeArm.rotation.x = THREE.MathUtils.lerp(0, -1.40, env);
            leftBones.leftForeArm.rotation.y = THREE.MathUtils.lerp(-0.45, -0.30, env);
            leftBones.leftForeArm.rotation.z = THREE.MathUtils.lerp(0, 0.70 - tapRecoil, env);
          }
          if (leftBones.leftHand) {
            leftBones.leftHand.rotation.set(0.10 * env, -0.15 * env, 0.05 * env);
          }

          // Girl outer arm rests naturally at side
          if (leftBones.rightArm) leftBones.rightArm.rotation.set(-2.192, -1.592, -0.742);
          if (leftBones.rightForeArm) leftBones.rightForeArm.rotation.set(0, 0.45, 0);

          // Boy raises RightArm forward holding mug to meet her cup at center
          if (rightBones.rightArm) {
            rightBones.rightArm.rotation.x = THREE.MathUtils.lerp(1.350, 1.30, env);
            rightBones.rightArm.rotation.y = THREE.MathUtils.lerp(0.600, 0.20, env);
            rightBones.rightArm.rotation.z = THREE.MathUtils.lerp(0.100, -0.30, env);
          }
          if (rightBones.rightForeArm) {
            rightBones.rightForeArm.rotation.x = THREE.MathUtils.lerp(0, -0.10, env);
            rightBones.rightForeArm.rotation.y = THREE.MathUtils.lerp(0, 0.20, env);
            rightBones.rightForeArm.rotation.z = THREE.MathUtils.lerp(0, -0.80 + tapRecoil, env);
          }
          if (rightBones.rightHand) {
            rightBones.rightHand.rotation.set(0.10 * env, 0.15 * env, -0.05 * env);
          }

          // Boy outer arm rests naturally at side
          if (rightBones.leftArm) rightBones.leftArm.rotation.set(1.350, -0.600, -0.100);
          if (rightBones.leftForeArm) rightBones.leftForeArm.rotation.set(0, 0, 0);

        } else if (currentEmote === 'kiss' && emoteProgress < 1.0) {
          // Hide coffee cups
          if (girlCupRef.current) girlCupRef.current.visible = false;
          if (boyCupRef.current) boyCupRef.current.visible = false;

          const env = Math.sin(emoteProgress * Math.PI) * (1 - 0.08 * Math.sin(emoteProgress * Math.PI * 2));

          // Romantic touching step-in for true lip-to-lip kiss proximity (+-0.095)
          leftModel.position.x = THREE.MathUtils.lerp(-0.38, -0.095, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.38, 0.095, env);
          leftModel.rotation.y = THREE.MathUtils.lerp(0, 0.48, env);
          rightModel.rotation.y = THREE.MathUtils.lerp(0, -0.48, env);

          // Romantic spine tilt toward partner
          if (leftBones.spine) leftBones.spine.rotation.z = -0.05 * env;
          if (rightBones.spine) rightBones.spine.rotation.z = 0.05 * env;

          // Head angles aligned directly for lip-to-lip contact
          if (leftBones.head) {
            leftBones.head.rotation.set(0.08 * env, 0.48 * env, 0.12 * env);
          }
          if (rightBones.head) {
            rightBones.head.rotation.set(0.08 * env, -0.48 * env, -0.12 * env);
          }

          // Girl arms wrap tenderly near boy's chest & neck
          if (leftBones.leftArm) {
            leftBones.leftArm.rotation.set(0.40 * env, -0.55 * env, 0.35 * env);
          }
          if (leftBones.leftForeArm) {
            leftBones.leftForeArm.rotation.set(-1.15 * env, -0.20 * env, 0.55 * env);
          }

          // Boy arms wrap tenderly near her waist & back
          if (rightBones.rightArm) {
            rightBones.rightArm.rotation.set(0.40 * env, 0.55 * env, -0.35 * env);
          }
          if (rightBones.rightForeArm) {
            rightBones.rightForeArm.rotation.set(-1.05 * env, 0.20 * env, -0.50 * env);
          }

          // Outer arms resting naturally close
          if (leftBones.rightArm) leftBones.rightArm.rotation.set(-2.192, -1.592, -0.742);
          if (leftBones.rightForeArm) leftBones.rightForeArm.rotation.set(0, 0.45, 0);
          if (rightBones.leftArm) rightBones.leftArm.rotation.set(1.350, -0.600, -0.100);
          if (rightBones.leftForeArm) rightBones.leftForeArm.rotation.set(0, 0, 0);

        } else if (currentEmote === 'hug' && emoteProgress < 1.0) {
          // Hide coffee cups
          if (girlCupRef.current) girlCupRef.current.visible = false;
          if (boyCupRef.current) boyCupRef.current.visible = false;

          const env = Math.sin(emoteProgress * Math.PI) * (1 - 0.10 * Math.sin(emoteProgress * Math.PI * 2));
          const squeeze = Math.sin((emoteProgress - 0.5) * 8) * 0.008;

          // Both avatars step into warm intimate couple embrace (+-0.082)
          leftModel.position.x = THREE.MathUtils.lerp(-0.38, -0.082 + squeeze, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.38, 0.082 - squeeze, env);
          leftModel.rotation.y = THREE.MathUtils.lerp(0, 0.32, env);
          rightModel.rotation.y = THREE.MathUtils.lerp(0, -0.32, env);

          // Heads rest lovingly on each other's shoulders
          if (leftBones.head) {
            leftBones.head.rotation.set(0.12 * env, 0.42 * env, 0.24 * env);
          }
          if (rightBones.head) {
            rightBones.head.rotation.set(0.12 * env, -0.42 * env, -0.22 * env);
          }

          // Spines lean into each other
          if (leftBones.spine) leftBones.spine.rotation.z = -0.04 * env;
          if (rightBones.spine) rightBones.spine.rotation.z = 0.04 * env;

          // Full two-arm wrapping embrace:
          // Girl wraps left arm over boy's shoulder/neck, right arm around boy's waist
          if (leftBones.leftArm) {
            leftBones.leftArm.rotation.set(0.40 * env, -0.60 * env, 0.25 * env);
          }
          if (leftBones.leftForeArm) {
            leftBones.leftForeArm.rotation.set(-1.30 * env, -0.20 * env, 0.70 * env);
          }
          if (leftBones.rightArm) {
            leftBones.rightArm.rotation.set(-1.35 * env, -0.75 * env, -0.45 * env);
          }
          if (leftBones.rightForeArm) {
            leftBones.rightForeArm.rotation.set(-0.80 * env, 0.30 * env, -0.40 * env);
          }

          // Boy wraps right arm across girl's upper back, left arm securely around waist
          if (rightBones.rightArm) {
            rightBones.rightArm.rotation.set(0.40 * env, 0.60 * env, -0.25 * env);
          }
          if (rightBones.rightForeArm) {
            rightBones.rightForeArm.rotation.set(-1.30 * env, 0.20 * env, -0.70 * env);
          }
          if (rightBones.leftArm) {
            rightBones.leftArm.rotation.set(1.05 * env, -0.40 * env, -0.30 * env);
          }
          if (rightBones.leftForeArm) {
            rightBones.leftForeArm.rotation.set(0.80 * env, 0.20 * env, -0.60 * env);
          }"""

assert old_emotes in code, "old_emotes not found"
code = code.replace(old_emotes, new_emotes, 1)

# 6. Idle positions and wrists
old_idle = """          // NATURAL RELAXED IDLE POSTURE (PALMS RESTING INWARD, ZERO HYPEREXTENSION)
          leftModel.position.x = THREE.MathUtils.lerp(leftModel.position.x, -0.44, 0.1);
          rightModel.position.x = THREE.MathUtils.lerp(rightModel.position.x, 0.44, 0.1);"""

new_idle = """          // NATURAL RELAXED IDLE POSTURE (PALMS RESTING INWARD, ZERO HYPEREXTENSION)
          leftModel.position.x = THREE.MathUtils.lerp(leftModel.position.x, -0.38, 0.1);
          rightModel.position.x = THREE.MathUtils.lerp(rightModel.position.x, 0.38, 0.1);"""

assert old_idle in code, "old_idle not found"
code = code.replace(old_idle, new_idle, 1)

old_idle_wrists = """          // Wrists: natural relaxed downward drop
          if (leftBones.leftHand) leftBones.leftHand.rotation.set(0.05, -0.10, -0.05);
          if (leftBones.rightHand) leftBones.rightHand.rotation.set(0.05, 0.10, 0.05);"""

new_idle_wrists = """          // Wrists: natural relaxed downward drop (no outward splay)
          if (leftBones.leftHand) leftBones.leftHand.rotation.set(0.04, -0.02, 0.0);
          if (leftBones.rightHand) leftBones.rightHand.rotation.set(0.04, 0.02, 0.0);"""

assert old_idle_wrists in code, "old_idle_wrists not found"
code = code.replace(old_idle_wrists, new_idle_wrists, 1)

with open(path, 'w', encoding='utf-8') as f:
    f.write(code)

print("Real3DAvatarStage.jsx successfully updated!")
