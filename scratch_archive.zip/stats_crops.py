from PIL import Image

def get_stats(path):
    img = Image.open(path).convert('RGB')
    pixels = list(img.getdata())
    r = sum(p[0] for p in pixels) / len(pixels)
    g = sum(p[1] for p in pixels) / len(pixels)
    b = sum(p[2] for p in pixels) / len(pixels)
    print(f"{path}: mean RGB=({r:.1f}, {g:.1f}, {b:.1f})")

get_stats('scratch/user_uploaded_hand.png')
get_stats('scratch/user_uploaded_girl_face.png')
get_stats('scratch/user_uploaded_boy_face.png')
get_stats('scratch/user_uploaded_boy_arm.png')
