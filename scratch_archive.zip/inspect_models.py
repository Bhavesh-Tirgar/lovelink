import struct
import json

def parse_glb(path, label):
    print(f"\n==================== {label}: {path} ====================")
    with open(path, 'rb') as f:
        magic, version, length = struct.unpack('<4sII', f.read(12))
        chunk_len, chunk_type = struct.unpack('<II', f.read(8))
        json_data = f.read(chunk_len).decode('utf-8', errors='ignore')
        g = json.loads(json_data)

    print(f"Nodes ({len(g.get('nodes', []))}):")
    for i, n in enumerate(g.get('nodes', [])):
        name = n.get('name', f'node_{i}')
        mesh = n.get('mesh')
        skin = n.get('skin')
        rot = n.get('rotation')
        trans = n.get('translation')
        if mesh is not None or any(k in name.lower() for k in ['arm', 'hand', 'head', 'body', 'skin', 'suit', 'face']):
            print(f"  Node {i:3d}: '{name}' | mesh={mesh} | skin={skin} | rot={rot} | trans={trans}")

    print(f"\nMeshes ({len(g.get('meshes', []))}):")
    for i, m in enumerate(g.get('meshes', [])):
        print(f"  Mesh {i:2d}: '{m.get('name')}'")
        for p in m.get('primitives', []):
            print(f"    primitive mat_id={p.get('material')}")

    print(f"\nMaterials ({len(g.get('materials', []))}):")
    for i, mat in enumerate(g.get('materials', [])):
        pbr = mat.get('pbrMetallicRoughness', {})
        base_color = pbr.get('baseColorFactor')
        tex = pbr.get('baseColorTexture')
        print(f"  Mat {i:2d}: '{mat.get('name')}' | baseColor={base_color} | tex={tex}")

parse_glb('lovelink-frontend/public/models/female_avatar.glb', 'FEMALE')
parse_glb('lovelink-frontend/public/models/male_avatar.glb', 'MALE')
