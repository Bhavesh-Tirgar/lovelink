import fs from 'fs';

console.log("=== RUNNING BOY PANTS & UI CLEANUP TDD TESTS ===");

let passed = 0;
let failed = 0;

function assert(condition, testName) {
  if (condition) {
    console.log(`  PASS: ${testName}`);
    passed++;
  } else {
    console.error(`  FAIL: ${testName}`);
    failed++;
  }
}

const stageCode = fs.readFileSync('lovelink-frontend/src/components/Real3DAvatarStage.jsx', 'utf8');

// 1. BOY_BOTTOMS contains pants with isPants: true
assert(
  stageCode.includes('isPants: true') && stageCode.includes('Indigo Denim Jeans') && stageCode.includes('Jet Black Slacks'),
  "BOY_BOTTOMS catalog must offer real pants (Jeans, Slacks, Chinos, Cargos) with isPants: true"
);

// 2. BOY_BOTTOMS contains shorts with isPants: false
assert(
  stageCode.includes('isPants: false') && (stageCode.includes('Shorts') || stageCode.includes('shorts')),
  "BOY_BOTTOMS catalog must offer shorts with isPants: false"
);

// 3. createBoyPantExtensions helper exists
assert(
  stageCode.includes('createBoyPantExtensions') && stageCode.includes('boyPantExtensionsRef'),
  "3D procedural pant leg extensions helper and ref must exist"
);

// 4. applyAllWardrobe toggles pant extensions visibility based on isPants
assert(
  stageCode.includes('boyPantExtensionsRef.current.visible = isPants') ||
  stageCode.includes('boyPantExtensionsRef.current.visible = !!isPants') ||
  stageCode.includes('boyPantExtensionsRef.current.visible = bottomItem.isPants !== false'),
  "applyAllWardrobe must show or hide pant extensions based on isPants"
);

// 5. Redundant clutter buttons removed (no raw .glb upload button, no camera button cluttering top dock)
assert(
  !stageCode.includes('Upload your custom 3D model (.glb)') &&
  !stageCode.includes('Save Snapshot Photo'),
  "Top dock clutter (raw GLB upload, duplicate camera button) must be removed for a clean UI"
);

console.log(`\nResults: ${passed} passed, ${failed} failed.`);
if (failed > 0) {
  process.exit(1);
} else {
  process.exit(0);
}
