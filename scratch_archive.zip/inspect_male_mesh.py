import struct
import json

with open('lovelink-frontend/public/models/male_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, _ = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))
    f.seek(12 + 8 + chunk_len)
    bin_len, _ = struct.unpack('<II', f.read(8))
    bin_data = f.read(bin_len)

accessors = g['accessors']
buffer_views = g['bufferViews']

def read_vec3(acc_idx):
    acc = accessors[acc_idx]
    bv = buffer_views[acc['bufferView']]
    offset = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    count = acc['count']
    return [struct.unpack_from('<3f', bin_data, offset + i * 12) for i in range(count)]

for m_idx in [4, 5, 6, 7]: # Body, Bottom, Footwear, Top
    m = g['meshes'][m_idx]
    name = m['name']
    p = m['primitives'][0]
    pos = read_vec3(p['attributes']['POSITION'])
    xs = [pt[0] for pt in pos]
    ys = [pt[1] for pt in pos]
    zs = [pt[2] for pt in pos]
    print(f"Mesh {m_idx} ('{name}'): {len(pos)} vertices")
    print(f"  Y range: [{min(ys):.3f}, {max(ys):.3f}]")
    print(f"  X range: [{min(xs):.3f}, {max(xs):.3f}]")
    print(f"  Z range: [{min(zs):.3f}, {max(zs):.3f}]")
