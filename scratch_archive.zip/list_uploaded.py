import os
from PIL import Image

dir_path = 'C:/Users/DELL/.gemini/antigravity/brain/fdad184e-3a97-4ef6-979f-0b1557260435/.user_uploaded'
for f in os.listdir(dir_path):
    if f.lower().endswith(('.png', '.jpg', '.jpeg')):
        p = os.path.join(dir_path, f)
        im = Image.open(p)
        print(f, im.size)
