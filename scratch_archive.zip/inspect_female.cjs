const fs = require('fs');
const path = require('path');

// Let's inspect female_avatar.glb JSON chunk
const buffer = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const magic = buffer.readUInt32LE(0);
const version = buffer.readUInt32LE(4);
const length = buffer.readUInt32LE(8);
const chunkLength = buffer.readUInt32LE(12);
const chunkType = buffer.readUInt32LE(16);

console.log('Magic:', magic.toString(16), 'Version:', version, 'Length:', length, 'ChunkLength:', chunkLength);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);

console.log('Meshes:');
gltf.meshes.forEach((m, idx) => {
  console.log(`Mesh ${idx}: ${m.name}`);
  m.primitives.forEach((p, pIdx) => {
    console.log(`  Prim ${pIdx}: material index = ${p.material}`);
  });
});

console.log('\nMaterials:');
gltf.materials.forEach((mat, idx) => {
  console.log(`Material ${idx}: ${mat.name}`);
  console.log('  pbrMetallicRoughness:', JSON.stringify(mat.pbrMetallicRoughness));
});

console.log('\nNodes:');
gltf.nodes.forEach((n, idx) => {
  if (n.mesh !== undefined || n.skin !== undefined) {
    console.log(`Node ${idx}: ${n.name}, mesh: ${n.mesh}, skin: ${n.skin}`);
  }
});
