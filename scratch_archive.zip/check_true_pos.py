import struct
import json

with open('lovelink-frontend/public/models/male_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, _ = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))
    f.seek(12 + 8 + chunk_len)
    bin_len, _ = struct.unpack('<II', f.read(8))
    bin_data = f.read(bin_len)

def get_positions(mesh_idx):
    p = g['meshes'][mesh_idx]['primitives'][0]
    acc_idx = p['attributes']['POSITION']
    acc = g['accessors'][acc_idx]
    bv = g['bufferViews'][acc['bufferView']]
    offset = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    stride = bv.get('byteStride', 12)
    count = acc['count']
    res = []
    for i in range(count):
        pt = struct.unpack_from('<3f', bin_data, offset + i * stride)
        res.append(pt)
    return res

bot_pts = get_positions(5)
xs = [p[0] for p in bot_pts]
ys = [p[1] for p in bot_pts]
zs = [p[2] for p in bot_pts]
print(f"Bottom (Shorts): {len(bot_pts)} vertices")
print(f"  X: [{min(xs):.3f}, {max(xs):.3f}]")
print(f"  Y: [{min(ys):.3f}, {max(ys):.3f}]")
print(f"  Z: [{min(zs):.3f}, {max(zs):.3f}]")

foot_pts = get_positions(6)
xs = [p[0] for p in foot_pts]
ys = [p[1] for p in foot_pts]
zs = [p[2] for p in foot_pts]
print(f"Footwear: {len(foot_pts)} vertices")
print(f"  X: [{min(xs):.3f}, {max(xs):.3f}]")
print(f"  Y: [{min(ys):.3f}, {max(ys):.3f}]")
print(f"  Z: [{min(zs):.3f}, {max(zs):.3f}]")
