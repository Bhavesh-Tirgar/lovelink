const fs = require('fs');

const code = fs.readFileSync('lovelink-frontend/src/components/Real3DAvatarStage.jsx', 'utf8');

console.log('Skin tones found:', code.includes('export const SKIN_TONES = ['));
console.log('curlFingers found:', code.includes('const curlFingers = (side) => {'));
console.log('clink found:', code.includes("if (currentEmote === 'clink'"));
console.log('idle found:', code.includes('// NATURAL RELAXED IDLE POSTURE'));
