const fs = require('fs');

const buffer = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const chunkLength = buffer.readUInt32LE(12);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);

const bodyMesh = gltf.meshes[0];
console.log('Body mesh primitives:');
bodyMesh.primitives.forEach((p, i) => {
  console.log(`Prim ${i}: material=${p.material}, attributes=`, Object.keys(p.attributes));
  // check accessor for POSITION to find min and max bounding box!
  const posAccessor = gltf.accessors[p.attributes.POSITION];
  console.log(`  min: ${posAccessor.min}, max: ${posAccessor.max}, count: ${posAccessor.count}`);
});
