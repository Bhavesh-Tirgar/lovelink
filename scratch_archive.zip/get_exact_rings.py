import struct
import json
import math

with open('lovelink-frontend/public/models/male_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, _ = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))
    f.seek(12 + 8 + chunk_len)
    bin_len, _ = struct.unpack('<II', f.read(8))
    bin_data = f.read(bin_len)

def get_positions(mesh_idx):
    p = g['meshes'][mesh_idx]['primitives'][0]
    acc_idx = p['attributes']['POSITION']
    acc = g['accessors'][acc_idx]
    bv = g['bufferViews'][acc['bufferView']]
    offset = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    stride = bv.get('byteStride', 12)
    count = acc['count']
    res = []
    for i in range(count):
        pt = struct.unpack_from('<3f', bin_data, offset + i * stride)
        res.append(pt)
    return res

bot_pts = get_positions(5)
foot_pts = get_positions(6)
body_pts = get_positions(4)

# shorts hem vertices (y < 0.66)
hem = [p for p in bot_pts if p[1] < 0.66]
left_hem = [p for p in hem if p[0] > 0]
right_hem = [p for p in hem if p[0] < 0]

def ring_stats(pts, name):
    cx = sum(p[0] for p in pts)/len(pts)
    cz = sum(p[2] for p in pts)/len(pts)
    rads = [math.sqrt((p[0]-cx)**2 + (p[2]-cz)**2) for p in pts]
    print(f"{name}: center=({cx:.4f}, {cz:.4f}), radius={sum(rads)/len(rads):.4f}")
    return cx, cz, sum(rads)/len(rads)

print("--- SHORTS HEM ---")
lcx, lcz, lrad = ring_stats(left_hem, "Left Shorts Hem")
rcx, rcz, rrad = ring_stats(right_hem, "Right Shorts Hem")

# shoe tops (y > 0.15)
shoe_top = [p for p in foot_pts if p[1] > 0.15]
left_shoe = [p for p in shoe_top if p[0] > 0]
right_shoe = [p for p in shoe_top if p[0] < 0]

print("--- SHOE TOPS ---")
s_lcx, s_lcz, s_lrad = ring_stats(left_shoe, "Left Shoe Top")
s_rcx, s_rcz, s_rrad = ring_stats(right_shoe, "Right Shoe Top")

print("\n--- BODY LEGS ---")
for y_val in [0.55, 0.45, 0.35, 0.25]:
    pts = [p for p in body_pts if abs(p[1] - y_val) < 0.02 and p[0] > 0]
    if pts:
        ring_stats(pts, f"Left Leg y={y_val}")
