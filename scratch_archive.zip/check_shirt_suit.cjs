const fs = require('fs');

const buffer = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const chunkLength = buffer.readUInt32LE(12);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);
const binChunk = buffer.subarray(28 + chunkLength);

const shirtMesh = gltf.meshes[9];
console.log('shirtMesh name:', shirtMesh.name);
const posAcc = gltf.accessors[shirtMesh.primitives[0].attributes.POSITION];
console.log('shirt pos min:', posAcc.min, 'max:', posAcc.max, 'count:', posAcc.count);

const suitMesh = gltf.meshes[11];
console.log('suitMesh name:', suitMesh.name);
const suitPosAcc = gltf.accessors[suitMesh.primitives[0].attributes.POSITION];
console.log('suit pos min:', suitPosAcc.min, 'max:', suitPosAcc.max, 'count:', suitPosAcc.count);
