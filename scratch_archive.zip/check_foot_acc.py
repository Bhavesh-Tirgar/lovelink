import struct
import json

with open('lovelink-frontend/public/models/male_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, _ = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))

p_foot = g['meshes'][6]['primitives'][0]
pos_foot_acc = g['accessors'][p_foot['attributes']['POSITION']]
print("Footwear POSITION accessor:", pos_foot_acc)
