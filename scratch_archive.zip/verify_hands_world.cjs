const THREE = require('../lovelink-frontend/node_modules/three');
const fs = require('fs');

// We have both GLBs:
// Let's inspect the positions of LeftHand and RightHand in world coordinates
const bufferF = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const chunkLengthF = bufferF.readUInt32LE(12);
const gltfF = JSON.parse(bufferF.subarray(20, 20 + chunkLengthF).toString('utf8'));

const bufferM = fs.readFileSync('lovelink-frontend/public/models/male_avatar.glb');
const chunkLengthM = bufferM.readUInt32LE(12);
const gltfM = JSON.parse(bufferM.subarray(20, 20 + chunkLengthM).toString('utf8'));

const findNodeF = (name) => gltfF.nodes.find(n => n.name === name);
const findNodeM = (name) => gltfM.nodes.find(n => n.name === name);

console.log('Female LeftHand node:', findNodeF('LeftHand'));
console.log('Female RightHand node:', findNodeF('RightHand'));

console.log('Male LeftHand node:', findNodeM('LeftHand'));
console.log('Male RightHand node:', findNodeM('RightHand'));
