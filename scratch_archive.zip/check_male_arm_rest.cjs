const fs = require('fs');

const buffer = fs.readFileSync('lovelink-frontend/public/models/male_avatar.glb');
const chunkLength = buffer.readUInt32LE(12);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);

const findNode = (name) => gltf.nodes.find(n => n.name === name);

console.log('Male LeftArm:', findNode('LeftArm'));
console.log('Male RightArm:', findNode('RightArm'));
console.log('Male LeftForeArm:', findNode('LeftForeArm'));
console.log('Male RightForeArm:', findNode('RightForeArm'));
