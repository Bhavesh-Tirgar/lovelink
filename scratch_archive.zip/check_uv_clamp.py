from PIL import Image

img_clean = Image.open('lovelink-frontend/public/models/female_skin_cleaned.png')
print("Cleaned pixel (0,0):", img_clean.getpixel((0, 0)))

img_orig = Image.open('scratch/extracted_female/0_body_base_color.png')
print("Orig pixel (0,0):", img_orig.getpixel((0, 0)))

# Also check texture wrap settings in original GLTF!
import struct, json
with open('lovelink-frontend/public/models/female_avatar.glb', 'rb') as f:
    magic, version, length = struct.unpack('<4sII', f.read(12))
    chunk_len, chunk_type = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))
    print("Samplers in female gltf:", g.get('samplers'))
    print("Textures in female gltf:", g.get('textures'))
