import struct
import json
import math

# Let's inspect the mesh skin weights for LeftHand and fingers
# to see where the vertices on the palm vs fingers move!
with open('lovelink-frontend/public/models/female_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, chunk_type = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))
    f.seek(12 + 8 + chunk_len)
    bin_len, bin_type = struct.unpack('<II', f.read(8))
    bin_data = f.read(bin_len)

# Nodes
nodes = g['nodes']
node_by_name = {n.get('name'): i for i, n in enumerate(nodes)}

# Look at LeftHand rest rotation vs LeftArm
left_hand_idx = node_by_name['LeftHand']
left_arm_idx = node_by_name['LeftArm']
left_forearm_idx = node_by_name['LeftForeArm']

print("LeftArm:", nodes[left_arm_idx])
print("LeftForeArm:", nodes[left_forearm_idx])
print("LeftHand:", nodes[left_hand_idx])
