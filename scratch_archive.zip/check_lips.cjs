const THREE = require('../lovelink-frontend/node_modules/three');

// Girl is at scale 1.18, boy is at scale 0.89
// Girl model position: y = 0.08, boy model position: y = 0.08
// In female_avatar.glb: head node y is at ~1.30 * 1.18 = 1.534m, lips at y = ~1.51m
// In male_avatar.glb: head bone y is at ~1.65 * 0.89 = 1.468m, lips at y = ~1.48m
console.log('Lip heights: Girl ~ 1.51m + 0.08 = 1.59m. Boy ~ 1.48m + 0.08 = 1.56m');
console.log('Height difference between girl and boy lips: ~0.03m (3cm)');
