const fs = require('fs');

const buffer = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const chunkLength = buffer.readUInt32LE(12);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);
const binChunk = buffer.subarray(28 + chunkLength);

const prim = gltf.meshes[0].primitives[0];
const posAcc = gltf.accessors[prim.attributes.POSITION];
const count = posAcc.count;
console.log('Vertex count:', count);

function readAccessor(accIdx) {
  const acc = gltf.accessors[accIdx];
  const bv = gltf.bufferViews[acc.bufferView];
  const start = (bv.byteOffset || 0) + (acc.byteOffset || 0);
  const stride = bv.byteStride || 0;
  return { acc, bv, start, stride };
}

const joints = readAccessor(prim.attributes.JOINTS_0);
const weights = readAccessor(prim.attributes.WEIGHTS_0);
const uvs = readAccessor(prim.attributes.TEXCOORD_0);

console.log('joints BV:', joints.bv);
console.log('weights BV:', weights.bv);
console.log('uvs BV:', uvs.bv);

const leftHandJoints = new Set([9, 11, 12, 13, 14, 15, 16, 18, 19, 20, 22, 23, 24, 26, 27, 28]);
const rightHandJoints = new Set([32, 34, 35, 36, 37, 38, 39, 41, 42, 43, 45, 46, 47, 49, 50, 51]);

let leftHandUVs = [];
let rightHandUVs = [];

for (let i = 0; i < count; i++) {
  const jOffset = joints.stride ? joints.start + i * joints.stride : joints.start + i * 4;
  const j0 = binChunk.readUInt8(jOffset);
  const j1 = binChunk.readUInt8(jOffset + 1);
  const j2 = binChunk.readUInt8(jOffset + 2);
  const j3 = binChunk.readUInt8(jOffset + 3);

  const wOffset = weights.stride ? weights.start + i * weights.stride : weights.start + i * 16;
  const w0 = binChunk.readFloatLE(wOffset);
  const w1 = binChunk.readFloatLE(wOffset + 4);
  const w2 = binChunk.readFloatLE(wOffset + 8);
  const w3 = binChunk.readFloatLE(wOffset + 12);

  const uOffset = uvs.stride ? uvs.start + i * uvs.stride : uvs.start + i * 8;
  const u = binChunk.readFloatLE(uOffset);
  const v = binChunk.readFloatLE(uOffset + 4);

  const check = (set) => (set.has(j0) && w0 > 0.1) || (set.has(j1) && w1 > 0.1) || (set.has(j2) && w2 > 0.1) || (set.has(j3) && w3 > 0.1);
  if (check(leftHandJoints)) leftHandUVs.push({ u, v });
  if (check(rightHandJoints)) rightHandUVs.push({ u, v });
}

console.log('Left hand count:', leftHandUVs.length, 'Right hand count:', rightHandUVs.length);

function bounds(arr) {
  let minU = 1e9, maxU = -1e9, minV = 1e9, maxV = -1e9;
  for (const p of arr) {
    if (p.u < minU) minU = p.u;
    if (p.u > maxU) maxU = p.u;
    if (p.v < minV) minV = p.v;
    if (p.v > maxV) maxV = p.v;
  }
  return { minU, maxU, minV, maxV };
}
console.log('Left hand UV bounds:', bounds(leftHandUVs));
console.log('Right hand UV bounds:', bounds(rightHandUVs));
