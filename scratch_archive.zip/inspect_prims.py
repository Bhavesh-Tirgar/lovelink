import struct
import json

with open('lovelink-frontend/public/models/female_avatar.glb', 'rb') as f:
    magic, version, length = struct.unpack('<4sII', f.read(12))
    chunk_len, chunk_type = struct.unpack('<II', f.read(8))
    json_data = f.read(chunk_len).decode('utf-8', errors='ignore')
    g = json.loads(json_data)
    bin_offset = 12 + 8 + chunk_len
    # read bin header
    f.seek(bin_offset)
    bin_len, bin_type = struct.unpack('<II', f.read(8))
    bin_data = f.read(bin_len)

# Accessors
accessors = g.get('accessors', [])
buffer_views = g.get('bufferViews', [])

def get_accessor_bounds(acc_idx):
    acc = accessors[acc_idx]
    return acc.get('min'), acc.get('max')

print("Mesh 0 ('body') primitives accessors:")
m0 = g['meshes'][0]
for idx, p in enumerate(m0['primitives']):
    pos_acc = p['attributes']['POSITION']
    min_b, max_b = get_accessor_bounds(pos_acc)
    mat_id = p.get('material')
    mat_name = g['materials'][mat_id].get('name') if mat_id is not None else 'None'
    print(f"  Prim {idx} (mat '{mat_name}'): bounds min={min_b}, max={max_b}")
