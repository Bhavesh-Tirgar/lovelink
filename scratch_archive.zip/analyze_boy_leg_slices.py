import struct
import json
import math

with open('lovelink-frontend/public/models/male_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, _ = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))
    f.seek(12 + 8 + chunk_len)
    bin_len, _ = struct.unpack('<II', f.read(8))
    bin_data = f.read(bin_len)

accessors = g['accessors']
buffer_views = g['bufferViews']

def read_vec3(acc_idx):
    acc = accessors[acc_idx]
    bv = buffer_views[acc['bufferView']]
    offset = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    count = acc['count']
    return [struct.unpack_from('<3f', bin_data, offset + i * 12) for i in range(count)]

# Wolf3D_Body leg vertices
p_body = g['meshes'][4]['primitives'][0]
pos_body = read_vec3(p_body['attributes']['POSITION'])

# Wolf3D_Outfit_Bottom vertices
p_bot = g['meshes'][5]['primitives'][0]
pos_bot = read_vec3(p_bot['attributes']['POSITION'])

# Let's inspect the bottom rim of the shorts
bot_rim = [p for p in pos_bot if p[1] < 0.64]
print(f"Shorts bottom rim vertices: {len(bot_rim)}")
left_bot = [p for p in bot_rim if p[0] > 0]
right_bot = [p for p in bot_rim if p[0] < 0]

def analyze_ring(pts, label):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    zs = [p[2] for p in pts]
    cx = sum(xs)/len(xs)
    cy = sum(ys)/len(ys)
    cz = sum(zs)/len(zs)
    rads = [math.sqrt((p[0]-cx)**2 + (p[2]-cz)**2) for p in pts]
    print(f"  {label}: center=({cx:.3f}, {cy:.3f}, {cz:.3f}), radius mean={sum(rads)/len(rads):.3f}, max={max(rads):.3f}")

print("Shorts leg openings:")
analyze_ring(left_bot, "Left leg opening")
analyze_ring(right_bot, "Right leg opening")

# Let's inspect the top of the shoes
p_foot = g['meshes'][6]['primitives'][0]
pos_foot = read_vec3(p_foot['attributes']['POSITION'])
foot_top = [p for p in pos_foot if p[1] > 0.14]
left_foot = [p for p in foot_top if p[0] > 0]
right_foot = [p for p in foot_top if p[0] < 0]
print("\nShoe tops:")
analyze_ring(left_foot, "Left shoe top")
analyze_ring(right_foot, "Right shoe top")

# Let's inspect the leg contour in between at y = 0.50 (knee), y = 0.35 (calf), y = 0.20 (ankle)
for target_y in [0.55, 0.45, 0.35, 0.25, 0.18]:
    slice_pts = [p for p in pos_body if abs(p[1] - target_y) < 0.02 and p[0] > 0]
    if slice_pts:
        xs = [p[0] for p in slice_pts]
        zs = [p[2] for p in slice_pts]
        cx = sum(xs)/len(xs)
        cz = sum(zs)/len(zs)
        rads = [math.sqrt((p[0]-cx)**2 + (p[2]-cz)**2) for p in slice_pts]
        print(f"Leg at y={target_y:.2f}: center=({cx:.3f}, {cz:.3f}), radius={sum(rads)/len(rads):.3f}")
