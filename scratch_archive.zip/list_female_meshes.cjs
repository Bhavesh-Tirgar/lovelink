const fs = require('fs');

const buffer = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const chunkLength = buffer.readUInt32LE(12);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);

console.log('Meshes in female_avatar.glb:');
gltf.meshes.forEach((m, idx) => {
  console.log(`Mesh ${idx}: name="${m.name}"`);
  m.primitives.forEach((p, pIdx) => {
    const mat = gltf.materials[p.material];
    console.log(`  Prim ${pIdx}: matIdx=${p.material}, matName="${mat?.name}", pbr=`, mat?.pbrMetallicRoughness);
  });
});
