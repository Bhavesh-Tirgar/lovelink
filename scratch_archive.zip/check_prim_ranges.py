import struct
import json

with open('lovelink-frontend/public/models/female_avatar.glb', 'rb') as f:
    magic, version, length = struct.unpack('<4sII', f.read(12))
    chunk_len, chunk_type = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))
    bin_offset = 12 + 8 + chunk_len
    f.seek(bin_offset)
    bin_len, bin_type = struct.unpack('<II', f.read(8))
    bin_data = f.read(bin_len)

accessors = g['accessors']
buffer_views = g['bufferViews']

def read_vec3(acc_idx):
    acc = accessors[acc_idx]
    bv = buffer_views[acc['bufferView']]
    offset = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    count = acc['count']
    return [struct.unpack_from('<3f', bin_data, offset + i * 12) for i in range(count)]

for i, p in enumerate(g['meshes'][0]['primitives']):
    mat_id = p.get('material')
    mat_name = g['materials'][mat_id]['name'] if mat_id is not None else 'None'
    pos = read_vec3(p['attributes']['POSITION'])
    # check min and max x
    xs = [pt[0] for pt in pos]
    ys = [pt[1] for pt in pos]
    print(f"Prim {i} ('{mat_name}'): {len(pos)} vertices | x range: [{min(xs):.3f}, {max(xs):.3f}] | y range: [{min(ys):.3f}, {max(ys):.3f}]")
