import re

path = 'lovelink-frontend/src/components/Real3DAvatarStage.jsx'
with open(path, 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Update SKIN_TONES
old_skin_tones = """export const SKIN_TONES = [
  { id: 'fair_warm', name: 'Fair Warm', boyHex: 0xffffff, girlHex: 0xce927b, swatch: '#ce927b', emoji: '🌸' },
  { id: 'golden_honey', name: 'Golden Honey', boyHex: 0xf5dac0, girlHex: 0xc4846d, swatch: '#c4846d', emoji: '🍯' },
  { id: 'warm_almond', name: 'Warm Almond', boyHex: 0xeac2a3, girlHex: 0xb5735b, swatch: '#b5735b', emoji: '☀️' },
  { id: 'bronze', name: 'Sun-Kissed Bronze', boyHex: 0xd4a682, girlHex: 0xa1624a, swatch: '#a1624a', emoji: '🌴' },
  { id: 'chestnut', name: 'Deep Chestnut', boyHex: 0x9f6946, girlHex: 0x76422f, swatch: '#76422f', emoji: '🌰' },
  { id: 'espresso', name: 'Rich Espresso', boyHex: 0x623e2a, girlHex: 0x482619, swatch: '#482619', emoji: '☕' },
];"""

new_skin_tones = """export const SKIN_TONES = [
  { id: 'fair_warm', name: 'Fair Warm', boyHex: 0xffffff, girlHex: 0xa9a9be, swatch: '#ce927b', emoji: '🌸' },
  { id: 'golden_honey', name: 'Golden Honey', boyHex: 0xf4dcbf, girlHex: 0xa1928e, swatch: '#c4846d', emoji: '🍯' },
  { id: 'warm_almond', name: 'Warm Almond', boyHex: 0xe6bda0, girlHex: 0x987e77, swatch: '#b5735b', emoji: '☀️' },
  { id: 'bronze', name: 'Sun-Kissed Bronze', boyHex: 0xd29f7c, girlHex: 0x8b6a5d, swatch: '#a1624a', emoji: '🌴' },
  { id: 'chestnut', name: 'Deep Chestnut', boyHex: 0x9c6543, girlHex: 0x674332, swatch: '#76422f', emoji: '🌰' },
  { id: 'espresso', name: 'Rich Espresso', boyHex: 0x633e28, girlHex: 0x42291e, swatch: '#482619', emoji: '☕' },
];"""

assert old_skin_tones in code, "old_skin_tones not found"
code = code.replace(old_skin_tones, new_skin_tones, 1)

# 2. Update initial female model scale and position
old_fem_load = """        const model = gltf.scene;
        model.position.set(-0.38, 0.08, 0);
        model.scale.set(1.18, 1.18, 1.18);"""

new_fem_load = """        const model = gltf.scene;
        model.position.set(-0.43, 0.08, 0);
        model.scale.set(1.14, 1.14, 1.14);"""

assert old_fem_load in code, "old_fem_load not found"
code = code.replace(old_fem_load, new_fem_load, 1)

# 3. Update female initial skin tone color (matching boy)
old_fem_skin_init = """            // Upgrade female skin to smooth human complexion (no anime clown blush)
            if (name.includes('body')) {
              const sm = Array.isArray(child.material) ? child.material[0] : child.material;
              sm.map = cleanSkinTex;
              sm.color.setHex(0xce927b); // Calibrated warm melanin tone matching boy
              sm.roughness = 0.68;
              sm.metalness = 0.0;
              sm.needsUpdate = true;
            }"""

new_fem_skin_init = """            // Upgrade female skin to smooth human complexion (no anime clown blush)
            if (name.includes('body')) {
              const sm = Array.isArray(child.material) ? child.material[0] : child.material;
              sm.map = cleanSkinTex;
              sm.color.setHex(0xa9a9be); // Calibrated warm melanin tone harmonized with boy
              sm.roughness = 0.68;
              sm.metalness = 0.0;
              sm.needsUpdate = true;
            }"""

assert old_fem_skin_init in code, "old_fem_skin_init not found"
code = code.replace(old_fem_skin_init, new_fem_skin_init, 1)

# 4. Update curlFingers to fix girl's left hand rotation
old_curl = """        // Natural graceful human resting finger curve (soft human relaxation, zero claw hyperextension)
        const curlFingers = (side) => {
          const prefix = side === 'left' ? 'leftHand' : 'rightHand';
          const isLeft = side === 'left';
          ['Index', 'Middle', 'Ring', 'Pinky'].forEach((f, idx) => {
            const curlAmt = 0.10 + idx * 0.015;
            for (let j = 1; j <= 3; j++) {
              const b = leftBonesRef.current[`${prefix}${f}${j}`];
              if (b) {
                const factor = j === 1 ? 0.6 : j === 2 ? 0.7 : 0.5;
                b.rotation.x = isLeft ? -curlAmt * factor : curlAmt * factor;
              }
            }
          });
          const t1 = leftBonesRef.current[`${prefix}Thumb1`];
          const t2 = leftBonesRef.current[`${prefix}Thumb2`];
          if (t1) {
            t1.rotation.set(isLeft ? -0.06 : 0.06, isLeft ? 0.05 : -0.05, isLeft ? -0.03 : 0.03);
          }
          if (t2) {
            t2.rotation.x = isLeft ? -0.08 : 0.08;
          }
        };"""

new_curl = """        // Natural graceful human resting finger curve (anatomical flexion forward into palm, zero claw hyperextension)
        const curlFingers = (side) => {
          const prefix = side === 'left' ? 'leftHand' : 'rightHand';
          ['Index', 'Middle', 'Ring', 'Pinky'].forEach((f, idx) => {
            const curlAmt = 0.08 + idx * 0.012;
            for (let j = 1; j <= 3; j++) {
              const b = leftBonesRef.current[`${prefix}${f}${j}`];
              if (b) {
                const factor = j === 1 ? 0.6 : j === 2 ? 0.7 : 0.5;
                // In female_avatar.glb, positive rotation.x curls fingers naturally forward into palm for BOTH hands
                b.rotation.x = curlAmt * factor;
              }
            }
          });
          const t1 = leftBonesRef.current[`${prefix}Thumb1`];
          const t2 = leftBonesRef.current[`${prefix}Thumb2`];
          if (t1) {
            t1.rotation.set(0.06, side === 'left' ? 0.05 : -0.05, side === 'left' ? -0.03 : 0.03);
          }
          if (t2) {
            t2.rotation.x = 0.08;
          }
        };"""

assert old_curl in code, "old_curl not found"
code = code.replace(old_curl, new_curl, 1)

# 5. Update initial male model scale and position
old_male_load = """        const model = gltf.scene;
        model.position.set(0.38, 0.08, 0);
        model.scale.set(0.89, 0.89, 0.89);"""

new_male_load = """        const model = gltf.scene;
        model.position.set(0.43, 0.08, 0);
        model.scale.set(0.96, 0.96, 0.96);"""

assert old_male_load in code, "old_male_load not found"
code = code.replace(old_male_load, new_male_load, 1)

# 6. Update Clink emote positions
old_clink_pos = """          // Both avatars step closer together to toast coffee
          leftModel.position.x = THREE.MathUtils.lerp(-0.38, -0.22, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.38, 0.22, env);"""

new_clink_pos = """          // Both avatars step closer together to toast coffee
          leftModel.position.x = THREE.MathUtils.lerp(-0.43, -0.20, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.43, 0.20, env);"""

assert old_clink_pos in code, "old_clink_pos not found"
code = code.replace(old_clink_pos, new_clink_pos, 1)

# 7. Update Kiss emote positions and head tilt (lip-to-lip)
old_kiss = """          // Romantic touching step-in for true lip-to-lip kiss proximity (+-0.095)
          leftModel.position.x = THREE.MathUtils.lerp(-0.38, -0.095, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.38, 0.095, env);
          leftModel.rotation.y = THREE.MathUtils.lerp(0, 0.48, env);
          rightModel.rotation.y = THREE.MathUtils.lerp(0, -0.48, env);

          // Romantic spine tilt toward partner
          if (leftBones.spine) leftBones.spine.rotation.z = -0.05 * env;
          if (rightBones.spine) rightBones.spine.rotation.z = 0.05 * env;

          // Head angles aligned directly for lip-to-lip contact
          if (leftBones.head) {
            leftBones.head.rotation.set(0.08 * env, 0.48 * env, 0.12 * env);
          }
          if (rightBones.head) {
            rightBones.head.rotation.set(0.08 * env, -0.48 * env, -0.12 * env);
          }"""

new_kiss = """          // Romantic touching step-in for true lip-to-lip kiss proximity (+-0.085)
          leftModel.position.x = THREE.MathUtils.lerp(-0.43, -0.085, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.43, 0.085, env);
          leftModel.rotation.y = THREE.MathUtils.lerp(0, 0.52, env);
          rightModel.rotation.y = THREE.MathUtils.lerp(0, -0.52, env);

          // Romantic spine tilt toward partner
          if (leftBones.spine) leftBones.spine.rotation.z = -0.05 * env;
          if (rightBones.spine) rightBones.spine.rotation.z = 0.05 * env;

          // Head angles aligned directly for realistic lip-to-lip contact
          if (leftBones.head) {
            leftBones.head.rotation.set(0.12 * env, 0.50 * env, 0.10 * env); // Girl tilts up lovingly
          }
          if (rightBones.head) {
            rightBones.head.rotation.set(-0.04 * env, -0.50 * env, -0.08 * env); // Boy leans gently down to her lips
          }"""

assert old_kiss in code, "old_kiss not found"
code = code.replace(old_kiss, new_kiss, 1)

# 8. Update Hug emote positions
old_hug = """          // Both avatars step into warm intimate couple embrace (+-0.082)
          leftModel.position.x = THREE.MathUtils.lerp(-0.38, -0.082 + squeeze, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.38, 0.082 - squeeze, env);"""

new_hug = """          // Both avatars step into warm intimate couple embrace (+-0.075)
          leftModel.position.x = THREE.MathUtils.lerp(-0.43, -0.075 + squeeze, env);
          rightModel.position.x = THREE.MathUtils.lerp(0.43, 0.075 - squeeze, env);"""

assert old_hug in code, "old_hug not found"
code = code.replace(old_hug, new_hug, 1)

# 9. Update Idle positions
old_idle = """          // NATURAL RELAXED IDLE POSTURE (PALMS RESTING INWARD, ZERO HYPEREXTENSION)
          leftModel.position.x = THREE.MathUtils.lerp(leftModel.position.x, -0.38, 0.1);
          rightModel.position.x = THREE.MathUtils.lerp(rightModel.position.x, 0.38, 0.1);"""

new_idle = """          // NATURAL RELAXED IDLE POSTURE (PALMS RESTING INWARD, ZERO HYPEREXTENSION, NO HAND CLIPPING)
          leftModel.position.x = THREE.MathUtils.lerp(leftModel.position.x, -0.43, 0.1);
          rightModel.position.x = THREE.MathUtils.lerp(rightModel.position.x, 0.43, 0.1);"""

assert old_idle in code, "old_idle not found"
code = code.replace(old_idle, new_idle, 1)

with open(path, 'w', encoding='utf-8') as f:
    f.write(code)

print("Stage perfection successfully applied!")
