global.self = global;
global.window = global;

import * as THREE from '../lovelink-frontend/node_modules/three/build/three.module.js';
import { GLTFLoader } from '../lovelink-frontend/node_modules/three/examples/jsm/loaders/GLTFLoader.js';
import fs from 'fs';

const femaleBuf = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const maleBuf = fs.readFileSync('lovelink-frontend/public/models/male_avatar.glb');

const loader = new GLTFLoader();

const createCoffeeCup = () => {
  const cupGroup = new THREE.Group();
  const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.034, 0.09, 24));
  cupGroup.add(cup);
  return cupGroup;
};

// Target meeting point: x=0, y=1.22, z=0.10
const target = new THREE.Vector3(0, 1.22, 0.10);

loader.parse(femaleBuf.buffer.slice(femaleBuf.byteOffset, femaleBuf.byteOffset + femaleBuf.byteLength), '', (gltfF) => {
  const girl = gltfF.scene;
  girl.position.set(-0.25, 0.08, 0);
  girl.scale.set(1.18, 1.18, 1.18);
  girl.rotation.y = 0.25;

  const gBones = {};
  girl.traverse(c => { if (c.isBone) gBones[c.name] = c; });

  const girlCup = createCoffeeCup();
  girlCup.position.set(0.015, 0.075, -0.01);
  if (gBones['LeftHand']) gBones['LeftHand'].add(girlCup);

  let bestGirlDist = 999;
  let bestGirlRot = null;

  // Grid search around reasonable lifting angles
  for (let ax = 0.4; ax <= 1.2; ax += 0.1) {
    for (let ay = -1.6; ay <= -0.4; ay += 0.15) {
      for (let az = 0.2; az <= 1.8; az += 0.15) {
        for (let fx = -1.4; fx <= 0; fx += 0.15) {
          for (let fz = -0.5; fz <= 0.8; fz += 0.2) {
            gBones['LeftArm'].rotation.set(ax, ay, az);
            gBones['LeftForeArm'].rotation.set(fx, -0.3, fz);
            girl.updateMatrixWorld(true);
            const pos = new THREE.Vector3();
            girlCup.getWorldPosition(pos);
            const d = pos.distanceTo(target);
            if (d < bestGirlDist) {
              bestGirlDist = d;
              bestGirlRot = { ax, ay, az, fx, fz, pos: pos.clone() };
            }
          }
        }
      }
    }
  }

  console.log("BEST GIRL CLINK:");
  console.log("  Dist:", bestGirlDist.toFixed(4));
  console.log("  Pos:", bestGirlRot.pos);
  console.log(`  Arm: (${bestGirlRot.ax.toFixed(2)}, ${bestGirlRot.ay.toFixed(2)}, ${bestGirlRot.az.toFixed(2)})`);
  console.log(`  ForeArm: (${bestGirlRot.fx.toFixed(2)}, -0.30, ${bestGirlRot.fz.toFixed(2)})`);

  // Solve Boy
  loader.parse(maleBuf.buffer.slice(maleBuf.byteOffset, maleBuf.byteOffset + maleBuf.byteLength), '', (gltfM) => {
    const boy = gltfM.scene;
    boy.position.set(0.25, 0.08, 0);
    boy.scale.set(0.89, 0.89, 0.89);
    boy.rotation.y = -0.25;

    const bBones = {};
    boy.traverse(c => { if (c.isBone) bBones[c.name] = c; });

    const boyCup = createCoffeeCup();
    boyCup.position.set(-0.015, 0.075, 0.01);
    if (bBones['RightHand']) bBones['RightHand'].add(boyCup);

    let bestBoyDist = 999;
    let bestBoyRot = null;

    for (let ax = 0.2; ax <= 1.4; ax += 0.1) {
      for (let ay = 0.2; ay <= 1.2; ay += 0.15) {
        for (let az = -1.2; az <= 0.2; az += 0.15) {
          for (let fx = -1.6; fx <= 0; fx += 0.15) {
            for (let fz = -0.8; fz <= 0.5; fz += 0.2) {
              bBones['RightArm'].rotation.set(ax, ay, az);
              bBones['RightForeArm'].rotation.set(fx, 0.2, fz);
              boy.updateMatrixWorld(true);
              const pos = new THREE.Vector3();
              boyCup.getWorldPosition(pos);
              const d = pos.distanceTo(target);
              if (d < bestBoyDist) {
                bestBoyDist = d;
                bestBoyRot = { ax, ay, az, fx, fz, pos: pos.clone() };
              }
            }
          }
        }
      }
    }

    console.log("\nBEST BOY CLINK:");
    console.log("  Dist:", bestBoyDist.toFixed(4));
    console.log("  Pos:", bestBoyRot.pos);
    console.log(`  Arm: (${bestBoyRot.ax.toFixed(2)}, ${bestBoyRot.ay.toFixed(2)}, ${bestBoyRot.az.toFixed(2)})`);
    console.log(`  ForeArm: (${bestBoyRot.fx.toFixed(2)}, 0.20, ${bestBoyRot.fz.toFixed(2)})`);

    const finalDist = bestGirlRot.pos.distanceTo(bestBoyRot.pos);
    console.log("\nFINAL DISTANCE BETWEEN MUGS:", finalDist.toFixed(4), "meters");
  });
});
