const fs = require('fs');

const buffer = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const chunkLength = buffer.readUInt32LE(12);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);
const binChunk = buffer.subarray(28 + chunkLength);

const prim = gltf.meshes[0].primitives[0];
const count = gltf.accessors[prim.attributes.POSITION].count;

function readAccessor(accIdx) {
  const acc = gltf.accessors[accIdx];
  const bv = gltf.bufferViews[acc.bufferView];
  const start = (bv.byteOffset || 0) + (acc.byteOffset || 0);
  const stride = bv.byteStride || 0;
  return { acc, bv, start, stride };
}

const joints = readAccessor(prim.attributes.JOINTS_0);
const weights = readAccessor(prim.attributes.WEIGHTS_0);
const uvs0 = readAccessor(prim.attributes.TEXCOORD_0);
const uvs1 = readAccessor(prim.attributes.TEXCOORD_1);
const uvs2 = readAccessor(prim.attributes.TEXCOORD_2);

const leftHandJoints = new Set([9, 11, 12, 13, 14, 15, 16, 18, 19, 20, 22, 23, 24, 26, 27, 28]);
const rightHandJoints = new Set([32, 34, 35, 36, 37, 38, 39, 41, 42, 43, 45, 46, 47, 49, 50, 51]);

let leftData = [];
for (let i = 0; i < count; i++) {
  const jOffset = joints.stride ? joints.start + i * joints.stride : joints.start + i * 4;
  const j0 = binChunk.readUInt8(jOffset);
  const j1 = binChunk.readUInt8(jOffset + 1);
  const j2 = binChunk.readUInt8(jOffset + 2);
  const j3 = binChunk.readUInt8(jOffset + 3);

  const wOffset = weights.stride ? weights.start + i * weights.stride : weights.start + i * 16;
  const w0 = binChunk.readFloatLE(wOffset);
  const w1 = binChunk.readFloatLE(wOffset + 4);
  const w2 = binChunk.readFloatLE(wOffset + 8);
  const w3 = binChunk.readFloatLE(wOffset + 12);

  const check = (set) => (set.has(j0) && w0 > 0.1) || (set.has(j1) && w1 > 0.1) || (set.has(j2) && w2 > 0.1) || (set.has(j3) && w3 > 0.1);
  if (check(leftHandJoints)) {
    const getUV = (accInfo) => {
      const offset = accInfo.stride ? accInfo.start + i * accInfo.stride : accInfo.start + i * 8;
      return [binChunk.readFloatLE(offset), binChunk.readFloatLE(offset + 4)];
    };
    leftData.push({
      uv0: getUV(uvs0),
      uv1: getUV(uvs1),
      uv2: getUV(uvs2)
    });
  }
}

console.log('Sample left hand UVs (first 10):');
console.log(leftData.slice(0, 10));

// Let's write all leftData to JSON so Python can plot it on the texture!
fs.writeFileSync('scratch/left_hand_uvs.json', JSON.stringify(leftData));
console.log('Saved scratch/left_hand_uvs.json');
