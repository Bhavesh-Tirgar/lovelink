from PIL import Image

# The user uploaded image 2:
img2_path = 'C:/Users/DELL/.gemini/antigravity/brain/fdad184e-3a97-4ef6-979f-0b1557260435/.user_uploaded/media_1794940706275_2dedc199.png'
img2 = Image.open(img2_path)
print("Image 2 size:", img2.size)

# Let's crop and inspect girl's face, girl's hand, boy's face, boy's hand
# In image 2 (size 590x983 or whatever):
w, h = img2.size
# girl is on left, boy on right
# girl hand: roughly around x=200-300, y=400-500
# Let's crop various areas and save them
# Girl left hand is near the center, between girl and boy: around x=250-290, y=390-440
crop_hand = img2.crop((int(w * 0.40), int(h * 0.38), int(w * 0.50), int(h * 0.46)))
crop_hand.save('scratch/user_uploaded_hand.png')

crop_girl_face = img2.crop((int(w * 0.18), int(h * 0.20), int(w * 0.38), int(h * 0.32)))
crop_girl_face.save('scratch/user_uploaded_girl_face.png')

crop_boy_face = img2.crop((int(w * 0.65), int(h * 0.13), int(w * 0.80), int(h * 0.23)))
crop_boy_face.save('scratch/user_uploaded_boy_face.png')

crop_boy_arm = img2.crop((int(w * 0.48), int(h * 0.28), int(w * 0.62), int(h * 0.42)))
crop_boy_arm.save('scratch/user_uploaded_boy_arm.png')

print("Cropped regions saved.")
