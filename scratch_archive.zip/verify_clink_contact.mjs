global.self = global;
global.window = global;

import * as THREE from '../lovelink-frontend/node_modules/three/build/three.module.js';
import { GLTFLoader } from '../lovelink-frontend/node_modules/three/examples/jsm/loaders/GLTFLoader.js';
import fs from 'fs';

const femaleBuf = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const maleBuf = fs.readFileSync('lovelink-frontend/public/models/male_avatar.glb');

const loader = new GLTFLoader();

const createCoffeeCup = () => {
  const cupGroup = new THREE.Group();
  const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.042, 0.034, 0.09, 24));
  cupGroup.add(cup);
  return cupGroup;
};

loader.parse(femaleBuf.buffer.slice(femaleBuf.byteOffset, femaleBuf.byteOffset + femaleBuf.byteLength), '', (gltfF) => {
  const girl = gltfF.scene;
  girl.position.set(-0.22, 0.08, 0);
  girl.scale.set(1.18, 1.18, 1.18);
  girl.rotation.y = 0.28;

  const gBones = {};
  girl.traverse(c => { if (c.isBone) gBones[c.name] = c; });

  const girlCup = createCoffeeCup();
  girlCup.position.set(0.015, 0.075, -0.01);
  if (gBones['LeftHand']) gBones['LeftHand'].add(girlCup);

  // Clink pose on girl:
  gBones['LeftArm'].rotation.set(0.50, -0.70, 0.40);
  gBones['LeftForeArm'].rotation.set(-0.85, -0.25, 0.50);
  gBones['LeftHand'].rotation.set(0.10, -0.15, 0.05);

  loader.parse(maleBuf.buffer.slice(maleBuf.byteOffset, maleBuf.byteOffset + maleBuf.byteLength), '', (gltfM) => {
    const boy = gltfM.scene;
    boy.position.set(0.22, 0.08, 0);
    boy.scale.set(0.89, 0.89, 0.89);
    boy.rotation.y = -0.28;

    const bBones = {};
    boy.traverse(c => { if (c.isBone) bBones[c.name] = c; });

    const boyCup = createCoffeeCup();
    boyCup.position.set(-0.015, 0.075, 0.01);
    if (bBones['RightHand']) bBones['RightHand'].add(boyCup);

    // Clink pose on boy:
    bBones['RightArm'].rotation.set(0.50, 0.70, -0.40);
    bBones['RightForeArm'].rotation.set(-0.85, 0.25, -0.50);
    bBones['RightHand'].rotation.set(0.10, 0.15, -0.05);

    girl.updateMatrixWorld(true);
    boy.updateMatrixWorld(true);

    const girlCupPos = new THREE.Vector3();
    const boyCupPos = new THREE.Vector3();
    girlCup.getWorldPosition(girlCupPos);
    boyCup.getWorldPosition(boyCupPos);

    console.log("=== COFFEE CUPS IN CLINK ===");
    console.log("Girl Cup Pos:", girlCupPos);
    console.log("Boy Cup Pos :", boyCupPos);
    const dist = girlCupPos.distanceTo(boyCupPos);
    console.log("Distance between cups:", dist.toFixed(3), "meters");
  });
});
