import struct
import json
import math

# We can parse the skeleton nodes of female_avatar.glb and compute forward kinematics for the left hand!
with open('lovelink-frontend/public/models/female_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, chunk_type = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))

# Let's inspect the children hierarchy of LeftHand
nodes = g['nodes']
node_by_name = {n.get('name'): i for i, n in enumerate(nodes)}

def print_tree(name, depth=0):
    idx = node_by_name.get(name)
    if idx is None: return
    n = nodes[idx]
    trans = n.get('translation', [0,0,0])
    rot = n.get('rotation', [0,0,0,1])
    print("  " * depth + f"{name}: trans={trans}")
    for ch_idx in n.get('children', []):
        print_tree(nodes[ch_idx].get('name'), depth + 1)

print("LeftHand skeleton tree:")
print_tree('LeftHand')

print("\nRightHand skeleton tree:")
print_tree('RightHand')
