global.self = global;
global.window = global;

import * as THREE from '../lovelink-frontend/node_modules/three/build/three.module.js';
import { GLTFLoader } from '../lovelink-frontend/node_modules/three/examples/jsm/loaders/GLTFLoader.js';
import fs from 'fs';

const maleBuf = fs.readFileSync('lovelink-frontend/public/models/male_avatar.glb');

const loader = new GLTFLoader();
loader.parse(maleBuf.buffer.slice(maleBuf.byteOffset, maleBuf.byteOffset + maleBuf.byteLength), '', (gltf) => {
  const model = gltf.scene;

  // Find Wolf3D_Outfit_Bottom
  let bottomMesh = null;
  model.traverse(c => {
    if (c.isMesh && c.name.toLowerCase().includes('bottom')) {
      bottomMesh = c;
    }
  });

  console.log("Found bottom mesh:", bottomMesh ? bottomMesh.name : "None");

  // Create procedural Pant Leg Extensions
  const pantsGroup = new THREE.Group();
  pantsGroup.name = "boy_pants_extensions";

  const createPantLeg = (isLeft) => {
    const legGeom = new THREE.CylinderGeometry(0.074, 0.055, 0.46, 24, 6, true);
    // slightly deform for natural human calf curve
    const pos = legGeom.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const y = pos.getY(i); // ranges from -0.23 to +0.23
      const normY = (y + 0.23) / 0.46; // 0 at bottom, 1 at top
      // Calf bulge around normY = 0.4
      const calfBulge = Math.sin(normY * Math.PI) * 0.007;
      pos.setX(i, pos.getX(i) * (1 + calfBulge));
      pos.setZ(i, pos.getZ(i) * (1 + calfBulge));
    }
    legGeom.computeVertexNormals();

    const legMesh = new THREE.Mesh(legGeom, bottomMesh ? bottomMesh.material : new THREE.MeshStandardMaterial());
    const sign = isLeft ? 1 : -1;
    legMesh.position.set(sign * 0.134, 0.395, -0.022);
    legMesh.rotation.set(0.04, 0, -sign * 0.05);
    return legMesh;
  };

  const leftPantLeg = createPantLeg(true);
  const rightPantLeg = createPantLeg(false);
  pantsGroup.add(leftPantLeg);
  pantsGroup.add(rightPantLeg);

  model.add(pantsGroup);

  console.log("Successfully created and attached boy 3D pant extensions!");
});
