import struct
import json
import math

def quat_to_euler(q):
    # q = [x, y, z, w]
    x, y, z, w = q
    # roll (x-axis rotation)
    sinr_cosp = 2 * (w * x + y * z)
    cosr_cosp = 1 - 2 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)

    # pitch (y-axis rotation)
    sinp = 2 * (w * y - z * x)
    if abs(sinp) >= 1:
        pitch = math.copysign(math.pi / 2, sinp)
    else:
        pitch = math.asin(sinp)

    # yaw (z-axis rotation)
    siny_cosp = 2 * (w * z + x * y)
    cosy_cosp = 1 - 2 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)

    return (roll, pitch, yaw)

with open('lovelink-frontend/public/models/female_avatar.glb', 'rb') as f:
    chunk_len = struct.unpack('<II', f.read(12)[8:12] + f.read(8)[:4])[0]
    # read json
    f.seek(12)
    chunk_len, chunk_type = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))

print("FEMALE ARMATURE BONE REST ROTATIONS:")
for i, n in enumerate(g['nodes']):
    name = n.get('name', '')
    if any(k in name.lower() for k in ['arm', 'forearm', 'hand']):
        q = n.get('rotation', [0, 0, 0, 1])
        e = quat_to_euler(q)
        print(f"  {name:18s}: quat={q}")
        print(f"  {' '*18}  euler (XYZ) = ({e[0]:.3f}, {e[1]:.3f}, {e[2]:.3f})")
