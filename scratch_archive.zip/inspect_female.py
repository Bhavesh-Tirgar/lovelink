import struct
import json

def parse_female():
    with open('lovelink-frontend/public/models/female_avatar.glb', 'rb') as f:
        magic, version, length = struct.unpack('<4sII', f.read(12))
        chunk_len, chunk_type = struct.unpack('<II', f.read(8))
        json_data = f.read(chunk_len).decode('utf-8', errors='ignore')
        g = json.loads(json_data)

    print("=== FEMALE NODES WITH MESHES ===")
    for i, n in enumerate(g.get('nodes', [])):
        if n.get('mesh') is not None:
            print(f"Node {i}: '{n.get('name')}', mesh={n.get('mesh')}")

    print("\n=== FEMALE MESHES ===")
    for i, m in enumerate(g.get('meshes', [])):
        print(f"Mesh {i}: '{m.get('name')}'")
        for p in m.get('primitives', []):
            mat_id = p.get('material')
            mat_name = g['materials'][mat_id].get('name') if mat_id is not None else 'None'
            print(f"  Primitive mat_id={mat_id} ('{mat_name}')")

    print("\n=== FEMALE MATERIALS ===")
    for i, mat in enumerate(g.get('materials', [])):
        pbr = mat.get('pbrMetallicRoughness', {})
        base_color = pbr.get('baseColorFactor')
        tex = pbr.get('baseColorTexture')
        print(f"Mat {i}: '{mat.get('name')}' | baseColorFactor={base_color} | tex={tex}")

parse_female()
