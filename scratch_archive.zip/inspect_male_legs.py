import struct
import json

with open('lovelink-frontend/public/models/male_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, _ = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))
    f.seek(12 + 8 + chunk_len)
    bin_len, _ = struct.unpack('<II', f.read(8))
    bin_data = f.read(bin_len)

accessors = g['accessors']
buffer_views = g['bufferViews']

def read_vec3(acc_idx):
    acc = accessors[acc_idx]
    bv = buffer_views[acc['bufferView']]
    offset = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    count = acc['count']
    return [struct.unpack_from('<3f', bin_data, offset + i * 12) for i in range(count)]

def read_vec2(acc_idx):
    acc = accessors[acc_idx]
    bv = buffer_views[acc['bufferView']]
    offset = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    count = acc['count']
    return [struct.unpack_from('<2f', bin_data, offset + i * 8) for i in range(count)]

p_body = g['meshes'][4]['primitives'][0]
pos_body = read_vec3(p_body['attributes']['POSITION'])
uv_body = read_vec2(p_body['attributes']['TEXCOORD_0'])

print("Wolf3D_Body vertex count:", len(pos_body))

# Let's inspect where leg vertices are in UV space
leg_uvs = []
arm_uvs = []
for p, (u, v) in zip(pos_body, uv_body):
    if p[1] < 0.7: # below waist
        leg_uvs.append((p, (u, v)))
    else:
        arm_uvs.append((p, (u, v)))

print(f"Leg vertices (y < 0.7): {len(leg_uvs)}")
if leg_uvs:
    u_min = min(uv[0] for _, uv in leg_uvs)
    u_max = max(uv[0] for _, uv in leg_uvs)
    v_min = min(uv[1] for _, uv in leg_uvs)
    v_max = max(uv[1] for _, uv in leg_uvs)
    print(f"Leg UV bounds: u=[{u_min:.3f}, {u_max:.3f}], v=[{v_min:.3f}, {v_max:.3f}]")

print(f"Upper body/arm vertices (y >= 0.7): {len(arm_uvs)}")
if arm_uvs:
    u_min = min(uv[0] for _, uv in arm_uvs)
    u_max = max(uv[0] for _, uv in arm_uvs)
    v_min = min(uv[1] for _, uv in arm_uvs)
    v_max = max(uv[1] for _, uv in arm_uvs)
    print(f"Upper body UV bounds: u=[{u_min:.3f}, {u_max:.3f}], v=[{v_min:.3f}, {v_max:.3f}]")
