from PIL import Image

img_orig = Image.open('scratch/extracted_female/0_body_base_color.png')
print("Original body_base_color size:", img_orig.size, img_orig.mode)

img_clean = Image.open('lovelink-frontend/public/models/female_skin_cleaned.png')
print("Cleaned skin size:", img_clean.size, img_clean.mode)

# Save thumbnail or inspect samples
w, h = img_clean.size
pixels = img_clean.load()

# sample grid
samples = []
for y in range(0, h, h // 8):
    for x in range(0, w, w // 8):
        samples.append(pixels[x, y][:3])

r_avg = sum(s[0] for s in samples) / len(samples)
g_avg = sum(s[1] for s in samples) / len(samples)
b_avg = sum(s[2] for s in samples) / len(samples)
print(f"Sampled average RGB: ({r_avg:.1f}, {g_avg:.1f}, {b_avg:.1f})")

# Let's inspect male head and body texture from male_avatar.glb as well!
