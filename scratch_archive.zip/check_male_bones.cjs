const fs = require('fs');

const buffer = fs.readFileSync('lovelink-frontend/public/models/male_avatar.glb');
const chunkLength = buffer.readUInt32LE(12);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);

console.log('Bones in male_avatar.glb:');
const skin = gltf.skins[0];
skin.joints.forEach((nodeIdx) => {
  const node = gltf.nodes[nodeIdx];
  console.log(`Node ${nodeIdx}: name="${node.name}"`);
});
