import struct
import json

with open('lovelink-frontend/public/models/female_avatar.glb', 'rb') as f:
    magic, version, length = struct.unpack('<4sII', f.read(12))
    chunk_len, chunk_type = struct.unpack('<II', f.read(8))
    json_data = f.read(chunk_len).decode('utf-8', errors='ignore')
    g = json.loads(json_data)
    bin_offset = 12 + 8 + chunk_len
    f.seek(bin_offset)
    bin_len, bin_type = struct.unpack('<II', f.read(8))
    bin_data = f.read(bin_len)

accessors = g['accessors']
buffer_views = g['bufferViews']

def read_accessor_vec3(acc_idx):
    acc = accessors[acc_idx]
    bv = buffer_views[acc['bufferView']]
    offset = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    count = acc['count']
    res = []
    for i in range(count):
        # 3 floats
        vals = struct.unpack_from('<3f', bin_data, offset + i * 12)
        res.append(vals)
    return res

def read_accessor_vec2(acc_idx):
    acc = accessors[acc_idx]
    bv = buffer_views[acc['bufferView']]
    offset = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    count = acc['count']
    res = []
    for i in range(count):
        vals = struct.unpack_from('<2f', bin_data, offset + i * 8)
        res.append(vals)
    return res

p0 = g['meshes'][0]['primitives'][0]
pos = read_accessor_vec3(p0['attributes']['POSITION'])
uv = read_accessor_vec2(p0['attributes']['TEXCOORD_0'])

# Left hand vertices: roughly x < -0.35, y around 0.6 - 0.9 in T-pose
# Let's check hand vertices:
left_hand_uvs = []
face_uvs = []
for p, (u, v) in zip(pos, uv):
    if p[0] < -0.4: # outer left arm/hand
        left_hand_uvs.append((u, v))
    if p[1] > 1.2: # face/head
        face_uvs.append((u, v))

print(f"Left hand vertices count: {len(left_hand_uvs)}")
if left_hand_uvs:
    u_min = min(u for u, v in left_hand_uvs)
    u_max = max(u for u, v in left_hand_uvs)
    v_min = min(v for u, v in left_hand_uvs)
    v_max = max(v for u, v in left_hand_uvs)
    print(f"Left hand UV bounds: u=[{u_min:.3f}, {u_max:.3f}], v=[{v_min:.3f}, {v_max:.3f}]")

print(f"Face vertices count: {len(face_uvs)}")
if face_uvs:
    u_min = min(u for u, v in face_uvs)
    u_max = max(u for u, v in face_uvs)
    v_min = min(v for u, v in face_uvs)
    v_max = max(v for u, v in face_uvs)
    print(f"Face UV bounds: u=[{u_min:.3f}, {u_max:.3f}], v=[{v_min:.3f}, {v_max:.3f}]")
