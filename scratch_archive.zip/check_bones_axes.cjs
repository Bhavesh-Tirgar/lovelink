const fs = require('fs');

const buffer = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const chunkLength = buffer.readUInt32LE(12);
const jsonChunk = buffer.subarray(20, 20 + chunkLength).toString('utf8');
const gltf = JSON.parse(jsonChunk);

console.log('Nodes for Left Hand vs Right Hand:');
const findNode = (name) => gltf.nodes.find(n => n.name === name);

console.log('LeftArm:', findNode('LeftArm'));
console.log('LeftForeArm:', findNode('LeftForeArm'));
console.log('LeftHand:', findNode('LeftHand'));
console.log('LeftHandIndex1:', findNode('LeftHandIndex1'));

console.log('RightArm:', findNode('RightArm'));
console.log('RightForeArm:', findNode('RightForeArm'));
console.log('RightHand:', findNode('RightHand'));
console.log('RightHandIndex1:', findNode('RightHandIndex1'));
