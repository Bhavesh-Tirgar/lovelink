import struct
import json

with open('lovelink-frontend/public/models/female_avatar.glb', 'rb') as f:
    magic, version, length = struct.unpack('<4sII', f.read(12))
    chunk_len, chunk_type = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))

for idx, p in enumerate(g['meshes'][0]['primitives']):
    print(f"Prim {idx} attributes:", list(p['attributes'].keys()))
