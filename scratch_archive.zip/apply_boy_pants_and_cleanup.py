path = 'lovelink-frontend/src/components/Real3DAvatarStage.jsx'
with open(path, 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Update BOY_BOTTOMS
old_bottoms = """export const BOY_BOTTOMS = [
  { id: 'raw_denim', name: 'Indigo Denim', color: 0x2b3d54, rough: 0.65, swatch: '#2b3d54', emoji: '👖' },
  { id: 'jet_black', name: 'Jet Black Jeans', color: 0x111215, rough: 0.55, swatch: '#111215', emoji: '🖤' },
  { id: 'espresso_chinos', name: 'Espresso Chinos', color: 0x36281e, rough: 0.6, swatch: '#36281e', emoji: '☕' },
  { id: 'slate_shorts', name: 'Slate Denim', color: 0x444c57, rough: 0.65, swatch: '#444c57', emoji: '🩶' },
  { id: 'off_white', name: 'Off-White Canvas', color: 0xdcdfe5, rough: 0.5, swatch: '#dcdfe5', emoji: '🤍' },
  { id: 'deep_olive', name: 'Olive Military', color: 0x242d20, rough: 0.65, swatch: '#242d20', emoji: '🪖' },
  { id: 'cyber_carbon', name: 'Cyber Carbon', color: 0x161622, rough: 0.3, swatch: '#161622', emoji: '🔮' },
  { id: 'charcoal_cargos', name: 'Charcoal Cargos', color: 0x23262b, rough: 0.6, swatch: '#23262b', emoji: '🪨' },
  { id: 'khaki_tailored', name: 'Tailored Khaki', color: 0x6e604f, rough: 0.55, swatch: '#6e604f', emoji: '🌾' },
];"""

new_bottoms = """export const BOY_BOTTOMS = [
  { id: 'raw_denim', name: 'Indigo Denim Jeans', color: 0x24324a, rough: 0.7, swatch: '#24324a', emoji: '👖', isPants: true },
  { id: 'jet_black', name: 'Jet Black Slacks', color: 0x111215, rough: 0.55, swatch: '#111215', emoji: '🖤', isPants: true },
  { id: 'espresso_chinos', name: 'Espresso Chinos', color: 0x36281e, rough: 0.6, swatch: '#36281e', emoji: '☕', isPants: true },
  { id: 'slate_trousers', name: 'Slate Gray Trousers', color: 0x3b434e, rough: 0.6, swatch: '#3b434e', emoji: '🩶', isPants: true },
  { id: 'linen_white', name: 'Off-White Slacks', color: 0xdcdfe5, rough: 0.55, swatch: '#dcdfe5', emoji: '🤍', isPants: true },
  { id: 'charcoal_cargos', name: 'Charcoal Cargo Pants', color: 0x23262b, rough: 0.65, swatch: '#23262b', emoji: '🪨', isPants: true },
  { id: 'khaki_tailored', name: 'Tailored Khaki Pants', color: 0x6e604f, rough: 0.55, swatch: '#6e604f', emoji: '🌾', isPants: true },
  { id: 'deep_olive', name: 'Olive Utility Pants', color: 0x242d20, rough: 0.65, swatch: '#242d20', emoji: '🪖', isPants: true },
  { id: 'cyber_carbon', name: 'Cyber Carbon Pants', color: 0x161622, rough: 0.3, swatch: '#161622', emoji: '🔮', isPants: true },
  { id: 'summer_shorts', name: 'Summer Denim Shorts', color: 0x444c57, rough: 0.65, swatch: '#444c57', emoji: '🩳', isPants: false },
  { id: 'bermuda_beige', name: 'Bermuda Resort Shorts', color: 0xb5a083, rough: 0.6, swatch: '#b5a083', emoji: '🏖️', isPants: false },
];"""

assert old_bottoms in code, "old_bottoms not found"
code = code.replace(old_bottoms, new_bottoms, 1)

# 2. Add boyPantExtensionsRef
old_refs = """  const sunglassesGroupRef = useRef(null);
  const girlCupRef = useRef(null);
  const boyCupRef = useRef(null);"""

new_refs = """  const sunglassesGroupRef = useRef(null);
  const girlCupRef = useRef(null);
  const boyCupRef = useRef(null);
  const boyPantExtensionsRef = useRef(null);"""

assert old_refs in code, "old_refs not found"
code = code.replace(old_refs, new_refs, 1)

# 3. In applyAllWardrobe: update boy bottom & toggle pant extensions
old_apply_bottom = """          } else if (name.includes('bottom')) {
            mat.color.setHex(bottomItem.color);
            mat.roughness = bottomItem.rough;
          }"""

new_apply_bottom = """          } else if (name.includes('bottom')) {
            mat.color.setHex(bottomItem.color);
            mat.roughness = bottomItem.rough;
          }"""

# In applyAllWardrobe after boy traversal:
old_shades = """      // Male Designer Sunglasses
      if (sunglassesGroupRef.current) {
        sunglassesGroupRef.current.visible = !!boyState.shades;
      }"""

new_shades = """      // Male 3D Tailored Pants Extensions (Real Pants vs Shorts)
      const isPants = bottomItem.isPants !== false;
      if (boyPantExtensionsRef.current) {
        boyPantExtensionsRef.current.visible = isPants;
        boyPantExtensionsRef.current.traverse((child) => {
          if (child.isMesh && child.material) {
            child.material.color.setHex(bottomItem.color);
            child.material.roughness = bottomItem.rough;
            child.material.needsUpdate = true;
          }
        });
      }

      // Male Designer Sunglasses
      if (sunglassesGroupRef.current) {
        sunglassesGroupRef.current.visible = !!boyState.shades;
      }"""

assert old_shades in code, "old_shades not found"
code = code.replace(old_shades, new_shades, 1)

# 4. Helper createBoyPantExtensions
old_coffee_helper = """    // HELPER: CREATE 3D REALISTIC CERAMIC COFFEE CUP PROP
    const createCoffeeCup = () => {"""

new_coffee_helper = """    // HELPER: CREATE 3D REALISTIC TAILORED PANT EXTENSIONS FOR BOY
    const createBoyPantExtensions = (bottomMaterial) => {
      const pantsGroup = new THREE.Group();
      pantsGroup.name = 'boy_pant_extensions';

      const createLeg = (isLeft) => {
        // Tapered tailored cylinder sleeve from shorts hem (y = 0.63) down to footwear top (y = 0.16)
        const legGeom = new THREE.CylinderGeometry(0.076, 0.054, 0.47, 24, 6, true);
        const pos = legGeom.attributes.position;
        for (let i = 0; i < pos.count; i++) {
          const y = pos.getY(i); // -0.235 to +0.235
          const normY = (y + 0.235) / 0.47; // 0 bottom, 1 top
          const calf = Math.sin(normY * Math.PI) * 0.006;
          pos.setX(i, pos.getX(i) * (1 + calf));
          pos.setZ(i, pos.getZ(i) * (1 + calf));
        }
        legGeom.computeVertexNormals();

        const mat = bottomMaterial ? bottomMaterial.clone() : new THREE.MeshStandardMaterial({ color: 0x24324a, roughness: 0.7 });
        const legMesh = new THREE.Mesh(legGeom, mat);
        const sign = isLeft ? 1 : -1;
        legMesh.position.set(sign * 0.134, 0.395, -0.022);
        legMesh.rotation.set(0.04, 0, -sign * 0.05);
        return legMesh;
      };

      pantsGroup.add(createLeg(true));
      pantsGroup.add(createLeg(false));
      return pantsGroup;
    };

    // HELPER: CREATE 3D REALISTIC CERAMIC COFFEE CUP PROP
    const createCoffeeCup = () => {"""

assert old_coffee_helper in code, "old_coffee_helper not found"
code = code.replace(old_coffee_helper, new_coffee_helper, 1)

# 5. Attach 3D pant extensions when male model loads
old_male_attach = """        mapBones(model, rightBonesRef);
        if (rightBonesRef.current.leftArm) {"""

new_male_attach = """        // Attach 3D Tailored Pant Leg Extensions (giving the boy real long pants/jeans)
        let bottomMat = null;
        model.traverse((child) => {
          if (child.isMesh && child.name.toLowerCase().includes('bottom') && child.material) {
            bottomMat = Array.isArray(child.material) ? child.material[0] : child.material;
          }
        });
        const pantsExt = createBoyPantExtensions(bottomMat);
        model.add(pantsExt);
        boyPantExtensionsRef.current = pantsExt;

        mapBones(model, rightBonesRef);
        if (rightBonesRef.current.leftArm) {"""

assert old_male_attach in code, "old_male_attach not found"
code = code.replace(old_male_attach, new_male_attach, 1)

# 6. Clean up top dock action buttons (remove Upload, RotateCw, Camera buttons)
old_top_actions = """          {/* Action Buttons */}
          <div className="flex items-center gap-1.5 pointer-events-auto">
            
            {/* Wardrobe Toggle */}
            <button
              onClick={() => setShowWardrobe(!showWardrobe)}
              className={`px-3 py-1.5 rounded-full backdrop-blur-md border border-white/20 shadow-xl transition-all active:scale-95 flex items-center gap-1.5 text-xs font-bold ${
                showWardrobe 
                  ? 'bg-gradient-to-r from-amber-400 to-rose-500 text-stone-950 font-black ring-2 ring-amber-300' 
                  : 'bg-black/60 hover:bg-black/80 text-white'
              }`}
              title="Change Clothes, Pants, Jackets & Style"
            >
              <Shirt size={13} className={showWardrobe ? 'text-stone-950' : 'text-amber-400'} />
              <span>Wardrobe</span>
            </button>

            {/* Custom .glb Model Upload */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-2 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md text-white border border-white/20 shadow-xl transition-all active:scale-95"
              title="Upload your custom 3D model (.glb)"
            >
              <Upload size={14} className="text-amber-400" />
            </button>

            {/* 360° Auto-Rotate Toggle */}
            <button
              onClick={() => setIsRotating(!isRotating)}
              className={`p-2 rounded-full backdrop-blur-md border border-white/20 shadow-xl transition-all active:scale-95 ${
                isRotating ? 'bg-amber-400 text-stone-950 font-bold' : 'bg-black/60 text-white'
              }`}
              title={isRotating ? 'Pause Auto-Spin' : 'Auto-Spin 360°'}
            >
              <RotateCw size={14} className={isRotating ? 'animate-spin' : ''} />
            </button>

            {/* Snapshot Camera */}
            <button
              onClick={handleCaptureSnapshot}
              className="p-2 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md text-white border border-white/20 shadow-xl transition-all active:scale-95"
              title="Save Snapshot Photo"
            >
              <Camera size={14} className="text-emerald-400" />
            </button>

            {/* 3D Avatar Creator from Selfie / Scratch */}
            <button
              onClick={onOpenCreator}
              className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-bold shadow-xl border border-white/20 active:scale-95 transition-all flex items-center gap-1.5"
              title="Create custom 3D avatar from selfie or scratch"
            >
              <Sparkles size={13} className="text-yellow-300" />
              <span>Customize 3D</span>
            </button>
          </div>"""

new_top_actions = """          {/* Action Buttons (Clean & Sleek Studio) */}
          <div className="flex items-center gap-2 pointer-events-auto">
            
            {/* Wardrobe Toggle */}
            <button
              onClick={() => setShowWardrobe(!showWardrobe)}
              className={`px-3.5 py-1.5 rounded-full backdrop-blur-md border border-white/20 shadow-xl transition-all active:scale-95 flex items-center gap-1.5 text-xs font-bold ${
                showWardrobe 
                  ? 'bg-gradient-to-r from-amber-400 to-rose-500 text-stone-950 font-black ring-2 ring-amber-300' 
                  : 'bg-black/60 hover:bg-black/80 text-white'
              }`}
              title="Change Clothes, Pants, Jackets & Style"
            >
              <Shirt size={14} className={showWardrobe ? 'text-stone-950' : 'text-amber-400'} />
              <span>Wardrobe</span>
            </button>

            {/* 3D Avatar Creator */}
            <button
              onClick={onOpenCreator}
              className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-bold shadow-xl border border-white/20 active:scale-95 transition-all flex items-center gap-1.5"
              title="Create custom 3D avatar from selfie or scratch"
            >
              <Sparkles size={13} className="text-yellow-300" />
              <span>Customize 3D</span>
            </button>
          </div>"""

assert old_top_actions in code, "old_top_actions not found"
code = code.replace(old_top_actions, new_top_actions, 1)

with open(path, 'w', encoding='utf-8') as f:
    f.write(code)

print("Real3DAvatarStage.jsx successfully updated with boy pants and cleaned UI!")
