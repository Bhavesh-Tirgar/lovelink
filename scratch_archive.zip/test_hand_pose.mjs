global.self = global;
global.window = global;

import * as THREE from '../lovelink-frontend/node_modules/three/build/three.module.js';
import { GLTFLoader } from '../lovelink-frontend/node_modules/three/examples/jsm/loaders/GLTFLoader.js';
import fs from 'fs';

const glbBuffer = fs.readFileSync('lovelink-frontend/public/models/female_avatar.glb');
const arrayBuffer = glbBuffer.buffer.slice(glbBuffer.byteOffset, glbBuffer.byteOffset + glbBuffer.byteLength);

const loader = new GLTFLoader();
loader.parse(arrayBuffer, '', (gltf) => {
  const model = gltf.scene;
  model.position.set(-0.38, 0.08, 0);
  model.scale.set(1.135, 1.135, 1.135);

  const bones = {};
  model.traverse((child) => {
    if (child.isBone) bones[child.name] = child;
  });

  const checkPose = (name, fn) => {
    fn();
    model.updateMatrixWorld(true);
    const lh = new THREE.Vector3();
    const rh = new THREE.Vector3();
    bones['LeftHand'].getWorldPosition(lh);
    bones['RightHand'].getWorldPosition(rh);
    console.log(`\n=== POSE: ${name} ===`);
    console.log(`  LeftHand : x=${lh.x.toFixed(3)}, y=${lh.y.toFixed(3)}, z=${lh.z.toFixed(3)}`);
    console.log(`  RightHand: x=${rh.x.toFixed(3)}, y=${rh.y.toFixed(3)}, z=${rh.z.toFixed(3)}`);
  };

  // Test Kiss peak (env = 1)
  checkPose('KISS (peak env=1)', () => {
    bones['LeftArm'].rotation.set(0.55, -0.65, 0.45);
    bones['LeftForeArm'].rotation.set(-1.15, -0.25, 0.65);
    bones['RightArm'].rotation.set(-2.192, -1.592, -0.742);
    bones['RightForeArm'].rotation.set(0, 0.45, 0);
  });

  // Test Hug peak (env = 1)
  checkPose('HUG (peak env=1)', () => {
    bones['LeftArm'].rotation.set(0.45, -0.65, 0.30);
    bones['LeftForeArm'].rotation.set(-1.35, -0.25, 0.75);
    bones['RightArm'].rotation.set(-1.45, -0.85, -0.55);
    bones['RightForeArm'].rotation.set(-0.85, 0.35, -0.45);
  });

  // Test Clink peak (env = 1)
  checkPose('CLINK (peak env=1)', () => {
    bones['LeftArm'].rotation.set(0.65, -0.85, 0.35);
    bones['LeftForeArm'].rotation.set(-0.75, -0.30, 0.45);
    bones['RightArm'].rotation.set(-2.192, -1.592, -0.742);
    bones['RightForeArm'].rotation.set(0, 0.45, 0);
  });

  // Test what was in commit 712b882 or earlier!
  // In commit 712b882:
  // leftArm: (0.958, -0.25, 2.3)
  // rightArm: (-0.958, 0.25, -2.3)
  checkPose('OLD COMMITTED POSE', () => {
    bones['LeftArm'].rotation.set(0.958, -0.25, 2.3);
    bones['RightArm'].rotation.set(-0.958, 0.25, -2.3);
    bones['LeftForeArm'].rotation.set(0, 0, 0);
    bones['RightForeArm'].rotation.set(0, 0, 0);
  });
});
