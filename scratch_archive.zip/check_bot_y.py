import struct
import json

with open('lovelink-frontend/public/models/male_avatar.glb', 'rb') as f:
    f.seek(12)
    chunk_len, _ = struct.unpack('<II', f.read(8))
    g = json.loads(f.read(chunk_len).decode('utf-8', errors='ignore'))
    f.seek(12 + 8 + chunk_len)
    bin_len, _ = struct.unpack('<II', f.read(8))
    bin_data = f.read(bin_len)

accessors = g['accessors']
buffer_views = g['bufferViews']

def read_vec3(acc_idx):
    acc = accessors[acc_idx]
    bv = buffer_views[acc['bufferView']]
    offset = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
    count = acc['count']
    return [struct.unpack_from('<3f', bin_data, offset + i * 12) for i in range(count)]

p_bot = g['meshes'][5]['primitives'][0]
pos_bot = read_vec3(p_bot['attributes']['POSITION'])
ys = [pt[1] for pt in pos_bot]
print(f"Wolf3D_Outfit_Bottom Y in bind pose: min={min(ys):.3f}, max={max(ys):.3f}")

p_foot = g['meshes'][6]['primitives'][0]
pos_foot = read_vec3(p_foot['attributes']['POSITION'])
ys_foot = [pt[1] for pt in pos_foot]
print(f"Wolf3D_Outfit_Footwear Y in bind pose: min={min(ys_foot):.3f}, max={max(ys_foot):.3f}")
