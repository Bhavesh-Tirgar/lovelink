// In Blender / glTF armatures for this character:
// Let's test the forward vector of the palm vs the finger tip
const fs = require('fs');

// We have Three.js in lovelink-frontend/node_modules/three!
const THREE = require('../lovelink-frontend/node_modules/three');

// Let's create a bone hierarchy for Left and Right hand
// and see which way +X or -X rotates the finger tip towards the palm (Z or -Z)!
const leftHand = new THREE.Bone();
const leftIndex1 = new THREE.Bone();
leftIndex1.position.set(0, 0.05, 0);
leftHand.add(leftIndex1);

const rightHand = new THREE.Bone();
const rightIndex1 = new THREE.Bone();
rightIndex1.position.set(0, 0.05, 0);
rightHand.add(rightIndex1);

// When we curl fingers into palm:
// In this rig, palm is at +Z or -Z?
console.log('Rig bone test created');
