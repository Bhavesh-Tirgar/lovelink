import fs from 'fs';
import path from 'path';

console.log("=== RUNNING AVATAR & ROOM TDD VERIFICATION ===");

let passed = 0;
let failed = 0;

function assert(condition, testName) {
  if (condition) {
    console.log(`  PASS: ${testName}`);
    passed++;
  } else {
    console.error(`  FAIL: ${testName}`);
    failed++;
  }
}

// 1. Test CSP in index.html
const indexHtml = fs.readFileSync('lovelink-frontend/public/index.html', 'utf8');
assert(
  indexHtml.includes('worker-src') && indexHtml.includes('blob:'),
  "index.html must have fallback meta Content-Security-Policy with worker-src and blob:"
);

// 2. Test CSP in root vercel.json
const rootVercelExists = fs.existsSync('vercel.json');
assert(rootVercelExists, "Root vercel.json must exist so Vercel applies headers from repo root");

// 3. Test Real3DAvatarStage.jsx for RepeatWrapping on cleanSkinTex
const stageCode = fs.readFileSync('lovelink-frontend/src/components/Real3DAvatarStage.jsx', 'utf8');
assert(
  stageCode.includes('cleanSkinTex.wrapS = THREE.RepeatWrapping') &&
  stageCode.includes('cleanSkinTex.wrapT = THREE.RepeatWrapping'),
  "cleanSkinTex must set RepeatWrapping for negative UV coordinates on female hands"
);

// 4. Test Model Scales: girl 1.14, boy 0.96 for matched head heights
assert(
  stageCode.includes('model.scale.set(1.14, 1.14, 1.14)') &&
  stageCode.includes('model.scale.set(0.96, 0.96, 0.96)'),
  "Model scales must be 1.14 for female and 0.96 for male so head heights match"
);

// 5. Test Kiss proximity: model positions step in to +-0.085
assert(
  stageCode.includes('-0.085') && stageCode.includes('0.085'),
  "Kiss emote must step avatars to +-0.085 for direct touching lip-to-lip contact"
);

// 6. Test Hug proximity: model positions step in to +-0.075
assert(
  stageCode.includes('-0.075') || stageCode.includes('-0.085'),
  "Hug emote must step avatars to touching chest-to-chest contact (+-0.075)"
);

// 7. Test Coffee Cups: cups meeting in center during clink
assert(
  stageCode.includes('girlCup') && stageCode.includes('boyCup') && stageCode.includes("createCoffeeCup"),
  "3D ceramic coffee mugs must be attached to hands and visible during clink"
);

console.log(`\nResults: ${passed} passed, ${failed} failed.`);
if (failed > 0) {
  process.exit(1);
} else {
  process.exit(0);
}
