import urllib.request
import json

url = 'https://api.github.com/repos/Bhavesh-Tirgar/lovelink/releases'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
try:
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read().decode())
        for rel in data:
            print(f"Tag: {rel['tag_name']}, Name: {rel['name']}, URL: {rel['html_url']}")
            for asset in rel.get('assets', []):
                print(f"  Asset: {asset['name']}, Size: {asset['size']/(1024*1024):.2f} MB, Download: {asset['browser_download_url']}")
except Exception as e:
    print('Error:', e)
