path = 'lovelink-frontend/src/components/Real3DAvatarStage.jsx'
with open(path, 'r', encoding='utf-8') as f:
    code = f.read()

# 1. Lucide imports
old_lucide = """import { 
  RotateCw, Sparkles, Heart, Coffee, 
  Music, Upload, RefreshCw, Camera, Box, Shirt, 
  Check, X, User, Lock
} from 'lucide-react';"""

new_lucide = """import { 
  Sparkles, Heart, Coffee, 
  Music, RefreshCw, Box, Shirt, 
  Check, X, User, Lock
} from 'lucide-react';"""

assert old_lucide in code, "old_lucide not found"
code = code.replace(old_lucide, new_lucide, 1)

# 2. fileInputRef & isRotating
old_state = """  const mountRef = useRef(null);
  const fileInputRef = useRef(null);
  
  // State: Emotes & Stage
  const [activeEmote, setActiveEmote] = useState(null);
  const [isRotating, setIsRotating] = useState(false);
  const [isLoading, setIsLoading] = useState(true);"""

new_state = """  const mountRef = useRef(null);
  
  // State: Emotes & Stage
  const [activeEmote, setActiveEmote] = useState(null);
  const [isLoading, setIsLoading] = useState(true);"""

assert old_state in code, "old_state not found"
code = code.replace(old_state, new_state, 1)

# 3. Remove handleFileUpload and handleCaptureSnapshot
old_handlers = """  // Handle Custom .glb Model Upload
  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.glb') && !file.name.toLowerCase().endsWith('.gltf')) {
      toast.error('Please upload a 3D .glb or .gltf file');
      return;
    }

    const objectUrl = URL.createObjectURL(file);
    setLocalMyGlb(objectUrl);
    toast.success(`Loaded 3D Model: ${file.name} ✨`);
  };

  // Screenshot / Snapshot Canvas
  const handleCaptureSnapshot = () => {
    if (!rendererRef.current) return;
    try {
      const dataUrl = rendererRef.current.domElement.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `lovelink_3d_couple_${Date.now()}.png`;
      a.click();
      confetti({ particleCount: 30, spread: 60, origin: { y: 0.5 } });
      toast.success('Snapshot saved to your device! 📸✨');
    } catch {
      toast.error('Could not capture snapshot');
    }
  };"""

assert old_handlers in code, "old_handlers not found"
code = code.replace(old_handlers, "", 1)

# 4. Remove controls.autoRotate = isRotating -> false
old_controls = """    controls.autoRotate = isRotating;
    controls.autoRotateSpeed = 1.2;"""
new_controls = """    controls.autoRotate = false;
    controls.autoRotateSpeed = 1.2;"""
assert old_controls in code, "old_controls not found"
code = code.replace(old_controls, new_controls, 1)

# 5. In animate loop: controls.autoRotate = false;
old_anim_rotate = """      // Update Controls
      controls.autoRotate = isRotating;
      controls.update();"""
new_anim_rotate = """      // Update Controls
      controls.autoRotate = false;
      controls.update();"""
assert old_anim_rotate in code, "old_anim_rotate not found"
code = code.replace(old_anim_rotate, new_anim_rotate, 1)

# 6. In useEffect deps: remove isRotating
old_deps = """  }, [isRotating, partnerGlbUrl, myGlbUrl, localMyGlb, localPartnerGlb, applyAllWardrobe, boyWardrobe, girlWardrobe]);"""
new_deps = """  }, [partnerGlbUrl, myGlbUrl, localMyGlb, localPartnerGlb, applyAllWardrobe, boyWardrobe, girlWardrobe]);"""
assert old_deps in code, "old_deps not found"
code = code.replace(old_deps, new_deps, 1)

# 7. Remove hidden file input
old_file_input = """      {/* Hidden File Input for Custom .glb upload */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".glb,.gltf"
        onChange={handleFileUpload}
        className="hidden"
      />"""
assert old_file_input in code, "old_file_input not found"
code = code.replace(old_file_input, "", 1)

with open(path, 'w', encoding='utf-8') as f:
    f.write(code)

print("Unused imports and handlers successfully cleaned!")
